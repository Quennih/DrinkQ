const fs = require('fs');
const path = require('path');

const rootDir = path.resolve(__dirname, '..');
const distDir = path.join(rootDir, 'public_dist');

const PUBLIC_ENTRIES = [
  '.htaccess',
  '.nojekyll',
  '_headers',
  '_redirects',
  '404.html',
  'assets',
  'index.html',
  'pages',
  'robots.txt',
  'sitemap.xml'
];

const BLOCKED_NAMES = new Set([
  'firebase.json',
  'netlify.toml',
  'README.md'
]);

const BLOCKED_PREFIXES = ['AUDIT_REPORT_', 'PATCH_SUMMARY_', 'FIX_REPORT_'];
const BLOCKED_DIRECTORIES = new Set(['functions', 'tools', 'node_modules', '.git', 'control-room']);
const BLOCKED_RELATIVE_PREFIXES = [
  'assets/js/config/',
  'assets/js/services/',
  'assets/css/control-room.css'
];

function normalizeRelative(filePath) {
  return path.relative(rootDir, filePath).replace(/\\/g, '/');
}

function shouldBlockName(name) {
  return BLOCKED_NAMES.has(name) || BLOCKED_PREFIXES.some((prefix) => name.startsWith(prefix));
}

function shouldBlockPath(source) {
  const relative = normalizeRelative(source);
  const name = path.basename(source);
  return shouldBlockName(name)
    || BLOCKED_DIRECTORIES.has(name)
    || BLOCKED_RELATIVE_PREFIXES.some((prefix) => relative === prefix || relative.startsWith(prefix));
}

function copyRecursive(source, target) {
  if (!fs.existsSync(source) || shouldBlockPath(source)) return;
  const stat = fs.statSync(source);

  if (stat.isDirectory()) {
    fs.mkdirSync(target, { recursive: true });
    for (const entry of fs.readdirSync(source)) {
      copyRecursive(path.join(source, entry), path.join(target, entry));
    }
    return;
  }

  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
}

function countArrayItems(sourceText, exportName) {
  const startPattern = `export const ${exportName} = [`;
  const start = sourceText.indexOf(startPattern);
  if (start < 0) return -1;
  const arrayStart = sourceText.indexOf('[', start);
  
  let depth = 0;
  let count = 0;
  let objectDepth = 0;
  let escape = false;
  const stack = [{ type: 'code' }];

  for (let index = arrayStart; index < sourceText.length; index += 1) {
    const char = sourceText[index];

    if (escape) {
      escape = false;
      continue;
    }

    const current = stack[stack.length - 1];

    if (current.type === 'string') {
      if (char === '\\') {
        escape = true;
        continue;
      }
      if (char === current.quote) {
        stack.pop();
        continue;
      }
      if (current.quote === '`' && char === '$' && sourceText[index + 1] === '{') {
        index += 1; // Skip the '{'
        stack.push({ type: 'template_expr', braceDepth: 1 });
        continue;
      }
      continue;
    }

    if (current.type === 'template_expr') {
      if (char === '"' || char === "'" || char === '`') {
        stack.push({ type: 'string', quote: char });
        continue;
      }
      if (char === '{') {
        current.braceDepth += 1;
        continue;
      }
      if (char === '}') {
        current.braceDepth -= 1;
        if (current.braceDepth === 0) {
          stack.pop();
        }
        continue;
      }
      continue;
    }

    // Default 'code' context
    if (char === '"' || char === "'" || char === '`') {
      stack.push({ type: 'string', quote: char });
      continue;
    }

    if (char === '[') {
      depth += 1;
      continue;
    }
    if (char === ']') {
      depth -= 1;
      if (depth === 0) break;
      continue;
    }
    if (depth === 1 && char === '{') {
      objectDepth += 1;
      continue;
    }
    if (depth === 1 && char === '}') {
      objectDepth -= 1;
      if (objectDepth === 0) {
        count += 1;
      }
      continue;
    }
  }

  return count;
}

function assertFileExists(relativePath) {
  const absolutePath = path.join(distDir, relativePath);
  if (!fs.existsSync(absolutePath)) {
    throw new Error(`Required public file missing after build: ${relativePath}`);
  }
}

function assertPublicDatabaseIntegrity() {
  const requiredFiles = [
    'assets/js/data/imported-encyclopedia-data.js',
    'assets/js/data/drinks.js',
    'assets/js/data/ingredients.js',
    'assets/js/data/categories.js',
    'assets/js/data/demo-data.js',
    'assets/js/public/catalog-data.js',
    'assets/js/public/drinks.js',
    'assets/js/public/ingredients.js',
    'assets/js/public/search.js',
    'assets/js/public/detail.js',
    'assets/js/public/home.js',
    'assets/js/shared/site-shell.js',
    'assets/js/shared/utils.js',
    'assets/css/site.css'
  ];

  requiredFiles.forEach(assertFileExists);

  const drinksText = fs.readFileSync(path.join(distDir, 'assets/js/data/drinks.js'), 'utf8');
  const ingredientsText = fs.readFileSync(path.join(distDir, 'assets/js/data/ingredients.js'), 'utf8');
  const drinkCount = countArrayItems(drinksText, 'importedDrinks');
  const ingredientCount = countArrayItems(ingredientsText, 'importedIngredients');

  if (drinkCount < 100 || ingredientCount < 60) {
    throw new Error(`Database incomplete in public_dist: ${drinkCount} drinks, ${ingredientCount} ingredients.`);
  }
}

function assertNoInternalFiles(directory) {
  const violations = [];
  const stack = [directory];

  while (stack.length) {
    const current = stack.pop();
    if (!fs.existsSync(current)) continue;

    for (const entry of fs.readdirSync(current)) {
      const fullPath = path.join(current, entry);
      const relativePath = path.relative(directory, fullPath).replace(/\\/g, '/');
      const stat = fs.statSync(fullPath);

      if (shouldBlockName(entry)
        || relativePath.startsWith('functions/')
        || relativePath.startsWith('tools/')
        || relativePath.startsWith('control-room/')
        || relativePath.startsWith('assets/js/config/')
        || relativePath.startsWith('assets/js/services/')
        || relativePath === 'assets/css/control-room.css') {
        violations.push(relativePath);
      }

      if (stat.isDirectory()) stack.push(fullPath);
    }
  }

  if (violations.length) {
    throw new Error(`Internal files leaked into public_dist: ${violations.join(', ')}`);
  }
}

fs.rmSync(distDir, { recursive: true, force: true });
fs.mkdirSync(distDir, { recursive: true });

for (const entry of PUBLIC_ENTRIES) {
  copyRecursive(path.join(rootDir, entry), path.join(distDir, entry));
}

assertNoInternalFiles(distDir);
assertPublicDatabaseIntegrity();
console.log(`DrinkQ public-only build created: ${distDir}`);
process.exit(0);
