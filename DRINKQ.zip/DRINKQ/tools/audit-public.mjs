import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');
const failures = [];

function fail(message) {
  failures.push(message);
}

function assert(condition, message) {
  if (!condition) fail(message);
}

function fileExists(relativePath) {
  return fs.existsSync(path.join(rootDir, relativePath));
}

function scanHtmlAssetReferences() {
  const htmlFiles = [
    'index.html',
    'pages/drinks.html',
    'pages/ingredients.html',
    'pages/search.html',
    'pages/detail.html',
    'pages/about.html',
    '404.html'
  ];

  const attrPattern = /\b(?:src|href)=["']([^"']+)["']/g;

  for (const htmlFile of htmlFiles) {
    const absoluteHtmlPath = path.join(rootDir, htmlFile);
    assert(fs.existsSync(absoluteHtmlPath), `HTML file missing: ${htmlFile}`);
    if (!fs.existsSync(absoluteHtmlPath)) continue;

    const html = fs.readFileSync(absoluteHtmlPath, 'utf8');
    const baseDir = path.dirname(htmlFile);
    let match;

    while ((match = attrPattern.exec(html))) {
      const rawUrl = match[1].trim();
      if (!rawUrl || rawUrl.startsWith('#') || /^(https?:|mailto:|tel:|data:|blob:)/i.test(rawUrl)) continue;

      const cleanUrl = rawUrl.split('?')[0].split('#')[0];
      if (!cleanUrl) continue;

      const target = path.normalize(path.join(baseDir, cleanUrl)).replaceAll('\\', '/');
      assert(fileExists(target), `Broken static reference in ${htmlFile}: ${rawUrl} -> ${target}`);
    }
  }
}

function scanForRestrictedLeaks() {
  const forbidden = [
    'control-room',
    'assets/js/config',
    'assets/js/services',
    'assets/css/control-room.css',
    'functions',
    'firestore.rules',
    'storage.rules',
    'firebase-status.html'
  ];

  for (const relativePath of forbidden) {
    assert(!fs.existsSync(path.join(rootDir, relativePath)), `Restricted file should be removed: ${relativePath}`);
  }

  const publicRouteFiles = ['_redirects', 'netlify.toml', 'firebase.json', 'robots.txt', '.htaccess'];
  for (const file of publicRouteFiles) {
    if (!fileExists(file)) continue;
    const content = fs.readFileSync(path.join(rootDir, file), 'utf8');
    assert(!/control-room\/login|control-room\/index|firebase-status\.html/.test(content), `Restricted route/reference remains in ${file}`);
  }
}

async function auditCatalogData() {
  globalThis.window = {
    location: { pathname: '/', search: '' },
    setTimeout,
    clearTimeout
  };

  const catalogUrl = pathToFileURL(path.join(rootDir, 'assets/js/public/catalog-data.js')).href;
  const catalog = await import(catalogUrl);
  const allItems = [...catalog.drinks, ...catalog.ingredients];
  const ids = new Set();

  assert(catalog.drinks.length >= 100, `Expected at least 100 drinks, found ${catalog.drinks.length}`);
  assert(catalog.ingredients.length >= 60, `Expected at least 60 ingredients, found ${catalog.ingredients.length}`);
  assert(allItems.length === catalog.drinks.length + catalog.ingredients.length, 'Catalog item total mismatch.');

  for (const item of allItems) {
    assert(item.id, `Item without id: ${item.name || 'unnamed'}`);
    assert(item.name, `Item without name: ${item.id || 'unknown-id'}`);
    if (ids.has(item.id)) fail(`Duplicate item id: ${item.id}`);
    ids.add(item.id);

    const source = catalog.imageSrc(item);
    assert(!source.startsWith('blob:'), `Blob image source is not durable for ${item.id}: ${source}`);
    const isRemoteImage = /^(https?:|data:image\/)/i.test(source);
    const isLocalImage = !isRemoteImage && fs.existsSync(path.join(rootDir, source));
    assert(isRemoteImage || isLocalImage, `Image source not resolvable for ${item.id}: ${source}`);
  }
}

scanHtmlAssetReferences();
scanForRestrictedLeaks();
await auditCatalogData();

if (failures.length) {
  console.error('DrinkQ public audit failed:');
  failures.forEach((message) => console.error(`- ${message}`));
  process.exit(1);
}

console.log('DrinkQ public audit passed: static references, catalog, images, and public-only cleanup are valid.');
process.exit(0);
