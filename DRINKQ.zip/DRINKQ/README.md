# DrinkQ Public Edition

DrinkQ adalah website ensiklopedia visual tentang minuman terkenal dunia, biji kopi, dan daun teh.

Versi ini dibuat lebih simpel untuk development dan deploy:

- Website berjalan static-first dari `assets/js/data/imported-encyclopedia-data.js`.
- Halaman publik dipertahankan: Home, Drinks, Ingredients, Search, Detail, About, dan 404.
- Data utama tetap tersimpan di source, lalu output deploy dibuat ke `public_dist/`.
- Tampilan sudah memakai layout responsif, kartu visual, filter, pencarian, dan footer pembuat.

## Pembuat

Web ini dibuat oleh:

- Vino Bimo Allfisyahr
- Revan Athallah

Email contact: vinobimo11@gmail.com  
Kontak ini masih sementara sampai email khusus DrinkQ dibuat.

## Struktur penting

```txt
index.html
about.html
drinks.html
ingredients.html
search.html
detail.html
404.html
assets/css/site.css
assets/js/public/
assets/js/shared/
assets/js/data/imported-encyclopedia-data.js
assets/images/
tools/build-public.cjs
tools/audit-public.mjs
```

## Cara cek lokal

```bash
npm run check
```

## Cara build

```bash
npm run build
```

Hasil build ada di:

```txt
public_dist/
```

Untuk deploy manual ke hosting biasa, upload isi folder `public_dist/`.

## Cara edit data

Edit file:

```txt
assets/js/data/imported-encyclopedia-data.js
```

Jangan simpan URL `blob:` atau link halaman Google Search sebagai gambar. Pakai file lokal di `assets/images/` atau direct image URL yang benar-benar membuka gambar.
