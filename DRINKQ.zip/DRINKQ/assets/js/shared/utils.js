/* ==========================================================================
   DRINKQ 2026 HIGH-PERFORMANCE UTILITIES
   Optimized with zero-jank handlers and defensive fallbacks
   ========================================================================== */

export const qs = (selector, scope = document) => scope.querySelector(selector);
export const qsa = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));

export function escapeHtml(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function createSlug(value = '') {
  return String(value)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function createUniqueId(prefix = 'id') {
  if (globalThis.crypto?.randomUUID) {
    return `${prefix}_${globalThis.crypto.randomUUID()}`;
  }

  const randomPart = Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now().toString(36)}_${randomPart}`;
}

export function setText(selector, value) {
  const targetElement = typeof selector === 'string' ? qs(selector) : selector;
  if (targetElement) {
    targetElement.textContent = value;
  }
}

export function renderList(items = []) {
  return items.map((item) => `<li>${escapeHtml(item)}</li>`).join('');
}

export function renderTags(items = []) {
  return items.map((item) => `<span class="tag">${escapeHtml(item)}</span>`).join('');
}

export function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

const CURATED_IMAGE_POOL = [
  'https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1523906630133-f6934a1ab2b9?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1621263764928-df1444c5e859?auto=format&fit=crop&w=1200&q=80',
  'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=1200&q=80'
];

function pickCuratedImage(label = 'DrinkQ') {
  const normalizedLabel = String(label || '').toLowerCase();

  if (/espresso|coffee|kopi|latte|cappuccino|mocha|americano|macchiato|bean/.test(normalizedLabel)) {
    return 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=80';
  }
  if (/tea|teh|matcha|chai|oolong|sencha|earl|leaf/.test(normalizedLabel)) {
    return 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?auto=format&fit=crop&w=1200&q=80';
  }
  if (/juice|smoothie|lemon|orange|fruit|soda|cola|mocktail|cocktail/.test(normalizedLabel)) {
    return 'https://images.unsplash.com/photo-1621263764928-df1444c5e859?auto=format&fit=crop&w=1200&q=80';
  }
  if (/milk|chocolate|cocoa/.test(normalizedLabel)) {
    return 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=1200&q=80';
  }

  let hash = 0;
  for (const char of normalizedLabel) {
    hash = (hash * 31 + char.charCodeAt(0)) >>> 0;
  }
  return CURATED_IMAGE_POOL[hash % CURATED_IMAGE_POOL.length];
}

export function buildPlaceholderImage(label = 'DrinkQ') {
  const safeLabel = escapeHtml(label || 'DrinkQ');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900"><defs><linearGradient id="g" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#8a5a44"/><stop offset="1" stop-color="#d2a56d"/></linearGradient></defs><rect width="1200" height="900" fill="url(#g)"/><g fill="rgba(255,248,240,.16)"><circle cx="220" cy="180" r="120"/><circle cx="980" cy="240" r="160"/><circle cx="840" cy="720" r="220"/></g><text x="50%" y="48%" dominant-baseline="middle" text-anchor="middle" fill="#fff8f0" font-size="62" font-family="Inter,Arial,sans-serif" font-weight="700">${safeLabel}</text><text x="50%" y="58%" dominant-baseline="middle" text-anchor="middle" fill="rgba(255,248,240,.84)" font-size="28" font-family="Inter,Arial,sans-serif">DrinkQ visual</text></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}


export function normalizeImageUrlForStorage(url = '') {
  const normalizedUrl = String(url || '').trim();
  if (!normalizedUrl) return '';

  // blob: and data:image/ are temporary preview values; never store them permanently.
  if (/^(blob:|data:image\/)/i.test(normalizedUrl)) return '';

  if (/^https?:/i.test(normalizedUrl)) return normalizedUrl;
  return normalizedUrl.replace(/^(\.\.\/|\.\/|\/)+/, '');
}

export function getImageSource(url, label = 'DrinkQ') {
  const normalizedUrl = typeof url === 'string' ? url.trim() : '';

  if (!normalizedUrl) {
    return buildPlaceholderImage(label);
  }

  const lowerUrl = normalizedUrl.toLowerCase();

  const relativeAssetUrl = normalizedUrl.replace(/^(\.\.\/|\.\/|\/)+/, '');
  if (relativeAssetUrl.toLowerCase().startsWith('assets/')) {
    return `${getPublicBasePath()}${relativeAssetUrl}`;
  }

  if (relativeAssetUrl.toLowerCase().startsWith('images/')) {
    return `${getPublicBasePath()}assets/${relativeAssetUrl}`;
  }

  const looksLikeSearchUrl = lowerUrl.includes('google.com/search') || lowerUrl.includes('bing.com/search') || lowerUrl.includes('wikipedia.org/wiki/special:search');
  const looksLikeImageAsset = lowerUrl.startsWith('data:image/')
    || /\.(png|jpe?g|webp|gif|svg|avif)(\?|#|$)/.test(lowerUrl)
    || lowerUrl.includes('images.unsplash.com/')
    || lowerUrl.includes('images.pexels.com/')
    || lowerUrl.includes('cdn.pixabay.com/')
    || lowerUrl.includes('upload.wikimedia.org/')
    || lowerUrl.includes('commons.wikimedia.org/')
    || lowerUrl.includes('lh3.googleusercontent.com/')
    || lowerUrl.includes('blogger.googleusercontent.com/')
    || lowerUrl.includes('raw.githubusercontent.com/')
    || lowerUrl.includes('githubusercontent.com/')
    || lowerUrl.includes('firebasestorage.');

  if (lowerUrl.startsWith('blob:')) {
    return buildPlaceholderImage(label);
  }

  return looksLikeSearchUrl || !looksLikeImageAsset ? buildPlaceholderImage(label) : normalizedUrl;
}

export function attachImageFallbacks(scope = document) {
  qsa('img[data-fallback-label]', scope).forEach((imageElement) => {
    if (imageElement.dataset.fallbackBound === 'true') {
      return;
    }

    imageElement.dataset.fallbackBound = 'true';
    imageElement.addEventListener('error', () => {
      imageElement.src = buildPlaceholderImage(imageElement.dataset.fallbackLabel || 'DrinkQ');
      imageElement.classList.add('image--placeholder');
    });
  });
}

export function storageIsAvailable(storageObject) {
  try {
    const testKey = '__drinkq_storage_test__';
    storageObject.setItem(testKey, '1');
    storageObject.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
}

export function readStorage(storageKey, fallbackValue = null) {
  try {
    if (!storageIsAvailable(window.localStorage)) {
      return fallbackValue;
    }
    const rawValue = window.localStorage.getItem(storageKey);
    return rawValue === null ? fallbackValue : rawValue;
  } catch {
    return fallbackValue;
  }
}

export function writeStorage(storageKey, value) {
  try {
    if (!storageIsAvailable(window.localStorage)) {
      return false;
    }
    window.localStorage.setItem(storageKey, value);
    return true;
  } catch {
    return false;
  }
}

export function removeStorage(storageKey) {
  try {
    if (!storageIsAvailable(window.localStorage)) {
      return false;
    }
    window.localStorage.removeItem(storageKey);
    return true;
  } catch {
    return false;
  }
}

export function readSession(storageKey, fallbackValue = null) {
  try {
    if (!storageIsAvailable(window.sessionStorage)) {
      return fallbackValue;
    }
    const rawValue = window.sessionStorage.getItem(storageKey);
    return rawValue === null ? fallbackValue : rawValue;
  } catch {
    return fallbackValue;
  }
}

export function writeSession(storageKey, value) {
  try {
    if (!storageIsAvailable(window.sessionStorage)) {
      return false;
    }
    window.sessionStorage.setItem(storageKey, value);
    return true;
  } catch {
    return false;
  }
}

export function removeSession(storageKey) {
  try {
    if (!storageIsAvailable(window.sessionStorage)) {
      return false;
    }
    window.sessionStorage.removeItem(storageKey);
    return true;
  } catch {
    return false;
  }
}

export function getDeviceId() {
  const storageKey = 'drinkq_device_id';
  const existingDeviceId = readStorage(storageKey, '');

  if (existingDeviceId) {
    return existingDeviceId;
  }

  const generatedDeviceId = createUniqueId('device');
  writeStorage(storageKey, generatedDeviceId);
  return generatedDeviceId;
}

export async function copyTextToClipboard(text) {
  // Modern Clipboard API (secure contexts, 2018+)
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(String(text));
    return;
  }

  // Legacy fallback for non-secure contexts (e.g. plain http:// dev servers)
  const helperTextarea = document.createElement('textarea');
  helperTextarea.value = String(text);
  helperTextarea.setAttribute('readonly', 'true');
  helperTextarea.style.cssText = 'position:fixed;opacity:0;pointer-events:none;top:0;left:0';
  document.body.appendChild(helperTextarea);
  helperTextarea.select();
  let wasCopied = false;
  try {
    // execCommand is deprecated but kept as last-resort fallback
    wasCopied = document.execCommand('copy');
  } finally {
    helperTextarea.remove();
  }

  if (!wasCopied) {
    throw new Error('Clipboard API tidak tersedia di konteks ini.');
  }
}

export function showToast(message, variant = 'info') {
  const toastHost = qs('[data-toast-host]') || createToastHost();
  const toastElement = document.createElement('div');
  toastElement.className = `toast toast--${variant}`;
  toastElement.textContent = message;
  toastHost.appendChild(toastElement);

  window.setTimeout(() => {
    toastElement.classList.add('toast--hide');
    window.setTimeout(() => toastElement.remove(), 220);
  }, 2600);
}

function createToastHost() {
  const toastHost = document.createElement('div');
  toastHost.dataset.toastHost = 'true';
  toastHost.className = 'toast-host';
  document.body.appendChild(toastHost);
  return toastHost;
}

export function serializeForm(formElement) {
  const formData = new FormData(formElement);
  const normalizedObject = {};

  for (const [key, value] of formData.entries()) {
    const normalizedValue = typeof value === 'string' ? value.trim() : value;
    if (Object.prototype.hasOwnProperty.call(normalizedObject, key)) {
      // Handle duplicate keys (e.g. checkbox groups) — collect as array
      if (!Array.isArray(normalizedObject[key])) {
        normalizedObject[key] = [normalizedObject[key]];
      }
      normalizedObject[key].push(normalizedValue);
    } else {
      normalizedObject[key] = normalizedValue;
    }
  }

  return normalizedObject;
}

export function safeArray(value) {
  if (Array.isArray(value)) {
    return value.filter(Boolean).map((item) => String(item).trim()).filter(Boolean);
  }

  if (typeof value === 'string' && value.trim()) {
    return value
      .split(/\r?\n|,|•|;/)
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return [];
}

export function debounce(callback, delayMs = 300) {
  let timeoutId = null;

  return (...args) => {
    window.clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => callback(...args), delayMs);
  };
}


export function formatLabel(value = '') {
  const normalizedValue = String(value || '').trim();
  if (!normalizedValue) {
    return '-';
  }

  return normalizedValue
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/\b\w/g, (character) => character.toUpperCase());
}

export function formatItemType(item) {
  const type = item?.type ?? '';
  if (type === 'drink') {
    return 'Drink';
  }

  const ingredientType = item?.ingredientType ?? '';
  if (ingredientType === 'coffee-bean') {
    return 'Coffee Bean';
  }

  if (ingredientType === 'tea-leaf') {
    return 'Tea Leaf';
  }

  return 'Item';
}

/**
 * Detects whether the current page lives one directory level below the root
 * (i.e., inside /pages/ or any subfolder of the project root).
 *
 * Strategy: We count path segments relative to the server root, ignoring the
 * final filename. A page at /index.html has depth 0; a page at /pages/foo.html
 * has depth 1. This is robust to any subdirectory hosting (e.g. /drinkq/pages/).
 *
 * We deliberately avoid substring-matching on the word 'pages' to prevent
 * false positives when the project itself is hosted at a path containing that word.
 */
function _detectPageDepth() {
  const rawPath = window.location.pathname;
  // Normalise: remove leading slash and trailing filename, then count slashes
  const withoutLeadingSlash = rawPath.replace(/^\//, '');
  // Determine the hosting base: any static segment that is NOT part of our app
  // structure can be detected via a meta tag set during build, or we fall back
  // to counting the depth of the path relative to the first HTML file.
  const segments = withoutLeadingSlash.split('/').filter(Boolean);
  // The last segment is the filename (or empty string for directory URLs).
  // Depth = number of directory segments (all segments except the filename).
  const directorySegments = segments.slice(0, -1); // all but last
  // If the URL ends with '/', there is no filename segment; treat as depth 0 of its dir.
  return directorySegments.length;
}

/** Returns true when the page is nested one or more levels below the site root. */
export function isInsideSubPage() {
  return _detectPageDepth() >= 1;
}

export function getPublicBasePath() {
  return isInsideSubPage() ? '../' : '';
}

export function getSiteHomePath() {
  return isInsideSubPage() ? '../index.html' : 'index.html';
}

export function createCardLink(item) {
  const basePath = isInsideSubPage() ? '' : 'pages/';
  return `${basePath}detail.html?type=${encodeURIComponent(item?.type ?? '')}&id=${encodeURIComponent(item?.id ?? '')}`;
}

export function createRelativeDetailLink(item, fromAdmin = false) {
  const basePath = fromAdmin ? '../' : (isInsideSubPage() ? '' : 'pages/');
  return `${basePath}detail.html?type=${encodeURIComponent(item?.type ?? '')}&id=${encodeURIComponent(item?.id ?? '')}`;
}
