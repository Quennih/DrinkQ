// DrinkQ Web Components untuk Modularitas UI

/**
 * Robust path detection: count directory depth instead of substring-matching '/pages/'.
 * Works correctly even when the project is hosted at a custom base path (e.g. /drinkq/).
 */
function _detectPageDepth() {
  const segments = window.location.pathname
    .replace(/^\//, '')
    .split('/')
    .filter(Boolean);
  // Remove the trailing filename segment (last segment with an extension or empty for dir URLs)
  const dirSegments = segments.slice(0, -1);
  return dirSegments.length;
}

function isInsideSubPage() {
  return _detectPageDepth() >= 1;
}

class DrinkQNavbar extends HTMLElement {
  connectedCallback() {
    const activePage = this.getAttribute('active') || 'beranda';
    const rootPrefix = isInsideSubPage() ? '../' : '';
    const pagePrefix = isInsideSubPage() ? '' : 'pages/';

    this.innerHTML = `
      <header class="site-header">
        <div class="container navbar">
          <a class="brand" href="${rootPrefix}index.html" aria-label="DrinkQ Home">
            <span class="brand__logo">DQ</span>
            <span><strong>DrinkQ</strong><small>The Beverage Guide</small></span>
          </a>
          <nav class="nav-links" aria-label="Navigasi utama">
            <a class="nav-link ${activePage === 'beranda' ? 'is-active' : ''}" href="${rootPrefix}index.html">Beranda</a>
            <a class="nav-link ${activePage === 'katalog' ? 'is-active' : ''}" href="${pagePrefix}drinks.html">Katalog</a>
            <a class="nav-link ${activePage === 'bahan' ? 'is-active' : ''}" href="${pagePrefix}ingredients.html">Bahan</a>
            <a class="nav-link ${activePage === 'eksplor' ? 'is-active' : ''}" href="${pagePrefix}search.html">Eksplor</a>
            <a class="nav-link ${activePage === 'kisah' ? 'is-active' : ''}" href="${pagePrefix}about.html">Kisah Kami</a>
          </nav>
        </div>
      </header>
      <noscript>
        <nav class="noscript-nav" aria-label="Navigasi fallback (tanpa JavaScript)">
          <a href="${rootPrefix}index.html">Beranda</a>
          <a href="${pagePrefix}drinks.html">Katalog</a>
          <a href="${pagePrefix}ingredients.html">Bahan</a>
          <a href="${pagePrefix}search.html">Eksplor</a>
          <a href="${pagePrefix}about.html">Kisah Kami</a>
        </nav>
      </noscript>
    `;
  }
}
customElements.define('drinkq-navbar', DrinkQNavbar);

class DrinkQFooter extends HTMLElement {
  connectedCallback() {
    const rootPrefix = isInsideSubPage() ? '../' : '';
    const pagePrefix = isInsideSubPage() ? '' : 'pages/';

    this.innerHTML = `
      <footer class="site-footer">
        <div class="container">
          <div class="site-footer__grid">
            <div>
              <a class="brand" href="${rootPrefix}index.html" aria-label="DrinkQ Home">
                <span class="brand__logo">DQ</span>
                <span><strong>DrinkQ</strong></span>
              </a>
              <p style="margin-top: 1rem; max-width: 300px;">Panduan ensiklopedia visual minuman premium dari seluruh dunia. Merayakan seni dan sejarah di setiap cangkir.</p>
            </div>
            <div>
              <h3>Eksplorasi</h3>
              <a href="${pagePrefix}drinks.html">Katalog Minuman</a>
              <a href="${pagePrefix}ingredients.html">Bahan Premium</a>
              <a href="${pagePrefix}search.html">Pencarian</a>
            </div>
            <div>
              <h3>Proyek Kami</h3>
              <a href="${pagePrefix}about.html">Kisah Kami</a>
              <a href="mailto:vinobimo11@gmail.com">Kontak</a>
            </div>
          </div>
          <div class="site-footer__copy">
            <span>&copy; 2026 DrinkQ. All rights reserved.</span>
            <span>Dibuat oleh Vino Bimo Allfisyahr &amp; Revan Athallah.</span>
          </div>
        </div>
      </footer>
    `;
  }
}
customElements.define('drinkq-footer', DrinkQFooter);
