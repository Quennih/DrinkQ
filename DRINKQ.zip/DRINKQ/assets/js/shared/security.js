// DrinkQ Security Notes
// File ini dulunya digunakan untuk proteksi client-side (seperti memblokir drag gambar).
// Namun, proteksi client-side sangat mudah di-bypass dan tidak memberikan keamanan nyata.
// 
// PENTING UNTUK BACKEND:
// Saat backend (SQL/Node.js/Supabase) diaktifkan, pastikan fitur keamanan berikut diimplementasikan di sisi server:
// 1. CORS (Cross-Origin Resource Sharing): Batasi origin yang bisa mengakses API.
// 2. Rate Limiting: Cegah serangan DDoS atau brute-force pada endpoint API.
// 3. SQL Injection Prevention: Gunakan parameterised queries atau ORM saat mengakses database.
// 4. Autentikasi & Autorisasi: Jika ada sistem admin, pastikan endpoint dilindungi dengan token (JWT/Session).

export function logSecurityNotice() {
  console.info("Security measures are delegated to the backend for robust protection.");
}
