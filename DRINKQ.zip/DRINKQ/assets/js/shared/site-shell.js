const RUNTIME_FLAGS = ['local', 'demo'];

function appendRuntimeFlag(url) {
  const rawUrl = String(url || '');
  if (!rawUrl || rawUrl.startsWith('#') || /^(https?:|mailto:|tel:|data:|blob:)/i.test(rawUrl)) return url;

  const [pathAndQuery, hash = ''] = rawUrl.split('#');
  const [path, query = ''] = pathAndQuery.split('?');
  const currentParams = new URLSearchParams(window.location.search || '');
  const targetParams = new URLSearchParams(query);

  RUNTIME_FLAGS.forEach((key) => {
    if (currentParams.get(key) === '1' && !targetParams.has(key)) targetParams.set(key, '1');
  });

  const nextQuery = targetParams.toString();
  return `${path}${nextQuery ? `?${nextQuery}` : ''}${hash ? `#${hash}` : ''}`;
}

function isInternalHtmlLink(href = '') {
  if (!href || href.startsWith('#') || /^(https?:|mailto:|tel:|data:|blob:)/i.test(href)) return false;
  return href.includes('.html') || href.startsWith('../') || href.startsWith('./');
}

function rewriteRuntimeLink(link) {
  if (!link?.getAttribute) return;
  const href = link.getAttribute('href');
  if (!isInternalHtmlLink(href)) return;
  link.setAttribute('href', appendRuntimeFlag(href));
}

function preserveRuntimeLinks(scope = document) {
  if (scope.matches?.('a[href]')) rewriteRuntimeLink(scope);
  scope.querySelectorAll?.('a[href]').forEach(rewriteRuntimeLink);
}

function qs(selector, scope = document) {
  return scope.querySelector(selector);
}

function closeNavigation(navLinks, toggleButton) {
  navLinks.classList.remove('is-open');
  toggleButton.classList.remove('is-open');
  toggleButton.setAttribute('aria-expanded', 'false');
  toggleButton.setAttribute('aria-label', 'Buka navigasi');
  document.body.classList.remove('has-open-nav');
}

function enhanceMobileNav() {
  const navbar = qs('.navbar');
  const navLinks = qs('.nav-links');
  if (!navbar || !navLinks || qs('.nav-toggle', navbar)) return;

  const toggleButton = document.createElement('button');
  toggleButton.type = 'button';
  toggleButton.className = 'nav-toggle';
  toggleButton.setAttribute('aria-expanded', 'false');
  toggleButton.setAttribute('aria-label', 'Buka navigasi');
  toggleButton.innerHTML = '<span></span><span></span><span></span>';

  toggleButton.addEventListener('click', () => {
    const isOpen = !navLinks.classList.contains('is-open');
    navLinks.classList.toggle('is-open', isOpen);
    toggleButton.classList.toggle('is-open', isOpen);
    toggleButton.setAttribute('aria-expanded', String(isOpen));
    toggleButton.setAttribute('aria-label', isOpen ? 'Tutup navigasi' : 'Buka navigasi');
    document.body.classList.toggle('has-open-nav', isOpen);
  });

  navLinks.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => closeNavigation(navLinks, toggleButton));
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && navLinks.classList.contains('is-open')) closeNavigation(navLinks, toggleButton);
  });

  navbar.appendChild(toggleButton);
}

/* ---- Navbar Scroll Elevation ---- */
function initScrollElevation() {
  const header = qs('.site-header');
  if (!header) return;

  let ticking = false;
  const onScroll = () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        header.classList.toggle('is-scrolled', window.scrollY > 10);
        ticking = false;
      });
      ticking = true;
    }
  };

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll(); // Set initial state
}

/* ---- Cinematic Page Load Entrance ---- */
function triggerPageLoadAnimation() {
  // Watch for the splash to be hidden via a custom event dispatched by home.js
  // If no splash exists or it's already hidden, reveal immediately.
  const splash = document.getElementById('splash-screen');
  if (splash && !splash.classList.contains('is-hidden') && splash.style.display !== 'none') {
    // Listen for the custom event that signals the splash is done
    document.addEventListener('drinkq:splashDone', () => {
      requestAnimationFrame(() => document.body.classList.add('page-loaded'));
    }, { once: true });
    // Hard safety cap: if the event never fires (e.g. no JS data), reveal after 5s
    setTimeout(() => document.body.classList.add('page-loaded'), 5000);
  } else {
    requestAnimationFrame(() => document.body.classList.add('page-loaded'));
  }
}

/* ---- Scroll Reveal: IntersectionObserver + MutationObserver ---- */
function initScrollReveal() {
  // Auto-add class to known structural selectors
  const autoRevealSelectors = ['.section-heading', '.intro-identity-card', '.spotlight', '.detail-card'];
  autoRevealSelectors.forEach(selector => {
    document.querySelectorAll(selector).forEach(el => {
      if (!el.classList.contains('reveal-on-scroll')) {
        el.classList.add('reveal-on-scroll');
      }
    });
  });

  // --- IntersectionObserver with batch stagger ---
  const revealObserver = new IntersectionObserver((entries, observer) => {
    // Collect only newly intersecting elements in this batch
    const intersecting = entries.filter(e => e.isIntersecting).map(e => e.target);

    intersecting.forEach((el, batchIndex) => {
      // Apply stagger only if element has no explicit data-delay already set
      if (!el.dataset.delay && intersecting.length > 1) {
        // Cap delay at step 5 to avoid excessively long waits
        const step = Math.min(batchIndex + 1, 5);
        el.style.transitionDelay = `${step * 80}ms`;
      }
      el.classList.add('is-revealed');
      observer.unobserve(el);
    });
  }, {
    root: null,
    rootMargin: '0px 0px -50px 0px',
    threshold: 0.1
  });

  // Observe all current elements
  document.querySelectorAll('.reveal-on-scroll').forEach(el => revealObserver.observe(el));

  // --- Highly Optimized MutationObserver to avoid scripting lag / main thread blocking ---
  let scanTimeout = null;
  const scheduleScan = () => {
    if (scanTimeout) return;
    scanTimeout = requestAnimationFrame(() => {
      document.querySelectorAll('.reveal-on-scroll:not(.is-revealed)').forEach(el => {
        revealObserver.observe(el);
      });
      scanTimeout = null;
    });
  };

  const mutationObserver = new MutationObserver((mutations) => {
    // Only schedule a scan if at least one actual element node was added
    let hasNewElements = false;
    for (let i = 0; i < mutations.length; i++) {
      const addedNodes = mutations[i].addedNodes;
      for (let j = 0; j < addedNodes.length; j++) {
        if (addedNodes[j].nodeType === 1) {
          hasNewElements = true;
          break;
        }
      }
      if (hasNewElements) break;
    }

    if (hasNewElements) {
      scheduleScan();
    }
  });

  mutationObserver.observe(document.body, { childList: true, subtree: true });

  // Export API for manual usage (e.g., older code calling refresh directly)
  window.DrinkQScrollReveal = {
    observe: (el) => revealObserver.observe(el),
    refresh: () => {
      document.querySelectorAll('.reveal-on-scroll:not(.is-revealed)').forEach(el => {
        revealObserver.observe(el);
      });
    }
  };
}

window.addEventListener('DOMContentLoaded', () => {
  preserveRuntimeLinks();

  // FIX: Use customElements.whenDefined() instead of setTimeout to guarantee
  // the Web Component is fully registered before enhancing mobile nav.
  customElements.whenDefined('drinkq-navbar').then(() => {
    enhanceMobileNav();
    preserveRuntimeLinks();
  });

  initScrollElevation();
  initScrollReveal();
  triggerPageLoadAnimation();
});
