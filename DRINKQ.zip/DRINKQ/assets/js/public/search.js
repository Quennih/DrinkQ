import { 
  allItems, 
  createSearchIndex, 
  debounce, 
  filterSearchIndex, 
  setText, 
  ensureCatalogReady, 
  getParam, 
  RenderEngine,
  itemTypeValue
} from './catalog-data.js';

const suggestions = ['coffee', 'tea', 'creamy', 'fresh', 'Japan', 'Indonesia', 'lemon', 'matcha'];

function getResponsiveBatchSize() {
  if (window.matchMedia?.('(max-width: 640px)').matches) return 10;
  if (window.matchMedia?.('(max-width: 1024px)').matches) return 14;
  return 18;
}

const BATCH_SIZE = getResponsiveBatchSize();
const state = { query: '', type: 'all', visibleLimit: BATCH_SIZE };
let catalogSearchIndex = [];

// Cache DOM references to eliminate queries inside rendering/scrolling loops
const dom = {
  grid: null,
  searchInput: null,
  typeSelect: null,
  suggestions: null,
  count: null,
  loadMoreButton: null
};

function initDOM() {
  dom.grid = document.querySelector('[data-results]');
  dom.searchInput = document.querySelector('[data-search]');
  dom.typeSelect = document.querySelector('[data-type]');
  dom.suggestions = document.querySelector('[data-suggestions]');
  dom.count = document.querySelector('[data-count]');
}

// Update URL parameters dynamically for perfect state sync
function updateURL(query) {
  try {
    const params = new URLSearchParams(window.location.search);
    if (query) {
      params.set('q', query);
    } else {
      params.delete('q');
    }
    const newRelativePathQuery = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
    window.history.replaceState(null, '', newRelativePathQuery);
  } catch (e) {
    console.warn('Gagal sinkronisasi parameter URL:', e);
  }
}

// Simulasi pencarian API
async function fetchSearchResults(query, type, limit, offset) {
  try {
    const params = new URLSearchParams({
      q: query || '',
      type: type || 'all',
      limit: String(limit || BATCH_SIZE),
      offset: String(offset || 0)
    });
    
    // Only attempt API if explicitly enabled via ?api=1 URL param
    if (!new URLSearchParams(window.location.search).has('api')) {
      throw new Error('Static mode, using local filtering.');
    }

    const response = await fetch(`/api/search?${params.toString()}`);
    if (!response.ok) throw new Error('API Pencarian gagal');
    const data = (await response.json()) ?? {};
    // Fallback if API returns empty for a wildcard query
    if ((!data.items || data.items.length === 0) && !query) {
      throw new Error('API mengembalikan hasil kosong, gunakan data lokal');
    }
    return {
      items: data.items ?? [],
      total: data.total ?? 0
    };
  } catch (error) {
    // Fallback: Filter lokal yang sangat aman dari undefined
    const results = filterSearchIndex(catalogSearchIndex, query)
      .filter((item) => {
        if (!item) return false;
        const val = itemTypeValue(item);
        return type === 'all' || val === type || (type === 'ingredient' && val !== 'drink');
      });

    return {
      items: results.slice(offset, offset + limit),
      total: results.length
    };
  }
}

function renderSuggestions() {
  if (!dom.suggestions) return;
  RenderEngine.renderSuggestions(dom.suggestions, suggestions);
}

function ensureLoadMoreButton() {
  if (!dom.grid) return null;
  if (dom.loadMoreButton) return dom.loadMoreButton;

  // Double check in DOM
  let button = document.querySelector('[data-load-more]');
  if (button) {
    dom.loadMoreButton = button;
    return button;
  }

  button = document.createElement('button');
  button.type = 'button';
  button.className = 'button button--primary catalog-load-more';
  button.dataset.loadMore = 'true';
  button.textContent = 'Muat lagi';
  button.addEventListener('click', handleLoadMore);
  dom.grid.insertAdjacentElement('afterend', button);
  dom.loadMoreButton = button;
  return button;
}

async function handleLoadMore() {
  if (dom.loadMoreButton) {
    dom.loadMoreButton.disabled = true;
    dom.loadMoreButton.textContent = 'Memuat...';
  }

  const currentRenderedCount = dom.grid?.querySelectorAll('.catalog-card').length ?? 0;
  const resultData = await fetchSearchResults(state.query, state.type, BATCH_SIZE, currentRenderedCount);
  const newItems = resultData.items || [];
  const totalResults = resultData.total || 0;

  // Append new items (zero layout shifts, zero DOM thrashing, preserves scroll position)
  RenderEngine.renderCatalogGrid(dom.grid, newItems, {
    append: true,
    startIndex: currentRenderedCount,
    emptyTitle: 'Tidak ada hasil',
    emptyMessage: 'Coba keyword lain seperti coffee, tea, creamy, atau nama negara.'
  });

  const finalRenderedCount = dom.grid?.querySelectorAll('.catalog-card').length ?? 0;
  state.visibleLimit = finalRenderedCount;

  updateLoadMoreUI(finalRenderedCount, totalResults);
}

function updateLoadMoreUI(renderedCount, totalResults) {
  const label = state.query
    ? `${renderedCount} ditampilkan dari ${totalResults} hasil untuk "${state.query}"`
    : `${renderedCount} ditampilkan dari ${allItems.length} katalog`;

  if (dom.count) dom.count.textContent = label;

  const loadMoreButton = ensureLoadMoreButton();
  if (loadMoreButton) {
    loadMoreButton.disabled = false;
    loadMoreButton.hidden = renderedCount >= totalResults;
    loadMoreButton.textContent = `Muat lagi (${Math.min(BATCH_SIZE, Math.max(0, totalResults - renderedCount))})`;
  }
}

async function render(isInitial = false) {
  if (!dom.grid) return;

  if (isInitial) {
    state.visibleLimit = BATCH_SIZE;
  }

  const resultData = await fetchSearchResults(state.query, state.type, state.visibleLimit, 0);
  const visibleResults = resultData.items || [];
  const totalResults = resultData.total || 0;

  // Render first batch (append = false)
  RenderEngine.renderCatalogGrid(dom.grid, visibleResults, {
    append: false,
    startIndex: 0,
    emptyTitle: 'Tidak ada hasil',
    emptyMessage: 'Coba keyword lain seperti coffee, tea, creamy, atau nama negara.'
  });

  updateLoadMoreUI(visibleResults.length, totalResults);
}

function renderLoadError(error) {
  console.error(error);
  if (dom.grid) {
    RenderEngine.renderError(dom.grid, 'Pencarian gagal dimuat', 'Coba refresh halaman. Jika masih error, buka dengan ?local=1 untuk memakai data lokal.');
  }
  if (dom.count) dom.count.textContent = 'Gagal memuat hasil';
}

window.addEventListener('DOMContentLoaded', async () => {
  let handleInput = null;
  let handleTypeChange = null;
  let handleSuggestionsClick = null;
  let handlePopState = null;

  try {
    initDOM();
    await ensureCatalogReady();
    catalogSearchIndex = createSearchIndex(allItems);
    
    state.query = getParam('q') || '';
    renderSuggestions();
    await render(true);

    if (dom.searchInput && state.query) {
      dom.searchInput.value = state.query;
    }

    // Set 300ms debounce
    handleInput = debounce(async (event) => {
      state.query = event.target.value.trim();
      updateURL(state.query);
      await render(true);
    }, 300);

    dom.searchInput?.addEventListener('input', handleInput);

    handleTypeChange = async (event) => {
      state.type = event.target.value;
      await render(true);
    };
    dom.typeSelect?.addEventListener('change', handleTypeChange);

    handleSuggestionsClick = async (event) => {
      const button = event.target.closest('[data-suggestion]');
      if (!button) return;
      state.query = button.dataset.suggestion;
      updateURL(state.query);
      if (dom.searchInput) dom.searchInput.value = state.query;
      await render(true);
    };
    dom.suggestions?.addEventListener('click', handleSuggestionsClick);

    // Sync state on browser Back/Forward actions
    handlePopState = async () => {
      const q = getParam('q') || '';
      state.query = q;
      if (dom.searchInput) dom.searchInput.value = q;
      await render(true);
    };
    window.addEventListener('popstate', handlePopState);

    // Prevent memory leaks on page unload
    window.addEventListener('unload', () => {
      dom.searchInput?.removeEventListener('input', handleInput);
      dom.typeSelect?.removeEventListener('change', handleTypeChange);
      dom.suggestions?.removeEventListener('click', handleSuggestionsClick);
      window.removeEventListener('popstate', handlePopState);
    }, { once: true });

  } catch (error) {
    renderLoadError(error);
  }
});