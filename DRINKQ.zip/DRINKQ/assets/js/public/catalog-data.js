import { importedDrinks, importedIngredients } from '../data/imported-encyclopedia-data.js';

const IMAGE_PLACEHOLDER = 'assets/images/placeholder.svg';

function buildInlinePlaceholder(label = 'DrinkQ') {
  const safeLabel = escapeHtml(String(label || 'DrinkQ')).slice(0, 42);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 900"><defs><linearGradient id="g" x1="0" x2="1" y1="0" y2="1"><stop stop-color="#704128"/><stop offset=".55" stop-color="#a7643c"/><stop offset="1" stop-color="#dca75a"/></linearGradient><radialGradient id="s" cx="28%" cy="20%" r="70%"><stop stop-color="#fff8ee" stop-opacity=".44"/><stop offset=".68" stop-color="#fff8ee" stop-opacity="0"/></radialGradient></defs><rect width="1200" height="900" rx="64" fill="url(#g)"/><rect width="1200" height="900" fill="url(#s)"/><g fill="rgba(255,248,238,.13)"><circle cx="210" cy="190" r="130"/><circle cx="980" cy="250" r="175"/><circle cx="820" cy="760" r="230"/></g><g transform="translate(492 230)" fill="#fff8ee" fill-opacity=".90"><rect x="40" y="40" width="210" height="300" rx="44"/><path d="M250 145h34c48 0 78 30 78 72s-32 72-78 72h-34v-45h28c21 0 35-10 35-27s-14-28-35-28h-28z"/></g><text x="50%" y="665" dominant-baseline="middle" text-anchor="middle" fill="#fff8ee" font-size="58" font-family="Inter,Arial,sans-serif" font-weight="900">${safeLabel}</text><text x="50%" y="730" dominant-baseline="middle" text-anchor="middle" fill="rgba(255,248,238,.82)" font-size="28" font-family="Inter,Arial,sans-serif" font-weight="700">DrinkQ visual</text></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function fallbackDrinks() {
  if (!Array.isArray(importedDrinks)) return [];
  return importedDrinks
    .map((item) => normalizeItem(item, 'drink'))
    .filter((item) => item && item.isPublished !== false)
    .sort((a, b) => String(a?.name || '').localeCompare(String(b?.name || '')));
}

function fallbackIngredients() {
  if (!Array.isArray(importedIngredients)) return [];
  return importedIngredients
    .map((item) => normalizeItem(item, 'ingredient'))
    .filter((item) => item && item.isPublished !== false)
    .sort((a, b) => String(a?.name || '').localeCompare(String(b?.name || '')));
}

function sortByName(items = []) {
  if (!Array.isArray(items)) return [];
  return [...items].sort((a, b) => String(a?.name || '').localeCompare(String(b?.name || '')));
}

export let drinks = fallbackDrinks();
export let ingredients = fallbackIngredients();
export let allItems = sortByName([...drinks, ...ingredients]);

const API_BASE_URL = '/api';

export async function fetchDrinksFromAPI() {
  try {
    // Only attempt API calls if explicitly enabled (static-first architecture)
    const params = new URLSearchParams(window.location.search);
    if (!params.has('api')) {
      return fallbackDrinks() ?? [];
    }
    const response = await fetch(`${API_BASE_URL}/drinks`);
    if (!response?.ok) throw new Error('API Gagal memuat data minuman');
    const data = (await response.json()) ?? [];
    if (!Array.isArray(data) || data.length === 0) {
      return fallbackDrinks() ?? [];
    }
    return data.map(item => normalizeItem(item, 'drink')) ?? [];
  } catch (error) {
    console.info("Menggunakan mock data untuk minuman (API belum tersedia).");
    return fallbackDrinks() ?? [];
  }
}

export async function fetchIngredientsFromAPI() {
  try {
    const params = new URLSearchParams(window.location.search);
    if (!params.has('api')) {
      return fallbackIngredients() ?? [];
    }
    const response = await fetch(`${API_BASE_URL}/ingredients`);
    if (!response?.ok) throw new Error('API Gagal memuat data bahan');
    const data = (await response.json()) ?? [];
    if (!Array.isArray(data) || data.length === 0) {
      return fallbackIngredients() ?? [];
    }
    return data.map(item => normalizeItem(item, 'ingredient')) ?? [];
  } catch (error) {
    console.info("Menggunakan mock data untuk bahan (API belum tersedia).");
    return fallbackIngredients() ?? [];
  }
}

export function itemTypeValue(item) {
  if (!item) return 'item';
  const type = item?.type ?? '';
  if (type === 'drink') return 'drink';
  const ingredientType = String(item?.ingredientType ?? item?.category ?? '').toLowerCase();
  if (ingredientType.includes('coffee') || ingredientType.includes('kopi')) return 'coffee-bean';
  if (ingredientType.includes('tea') || ingredientType.includes('teh')) return 'tea-leaf';
  return 'ingredient';
}

let catalogReadyPromise = null;

const RELATION_STOP_WORDS = new Set(['air', 'dan', 'yang', 'dengan', 'dalam', 'untuk', 'dari', 'atau', 'pada', 'adalah', 'sebagai', 'minuman', 'drink', 'drinks', 'world', 'dunia', 'global', 'history', 'sejarah', 'asal', 'profil', 'rasa', 'basic', 'classic', 'refreshing', 'tradisional', 'traditional', 'terkenal', 'popular', 'populer', 'manusia', 'peradaban', 'biasanya', 'disajikan', 'seduh', 'sajian', 'utama']);

function keywordSet(value = '') {
  return new Set(String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s-]+/g, ' ')
    .split(/[\s-]+/)
    .filter((term) => term.length > 2 && !RELATION_STOP_WORDS.has(term)));
}

function itemKeywords(item = {}) {
  if (!item) return new Set();
  return keywordSet([
    item.name,
    item.category,
    item.categoryLabel,
    item.ingredientType,
    item.ingredientTypeLabel,
    item.origin,
    item.originRegion,
    item.shortDescription,
    item.story,
    item.history,
    ...(Array.isArray(item.tasteNotes) ? item.tasteNotes : []),
    ...(Array.isArray(item.ingredients) ? item.ingredients : []),
    ...(Array.isArray(item.brewingTips) ? item.brewingTips : [])
  ].join(' '));
}

// --- High-Performance Cached Getters to solve O(D x I) calculation bottlenecks ---
function getKeywordsCached(item) {
  if (!item) return new Set();
  if (!item._cachedKeywords) {
    item._cachedKeywords = itemKeywords(item);
  }
  return item._cachedKeywords;
}

function getSearchTextCached(item) {
  if (!item) return '';
  if (!item._cachedSearchText) {
    item._cachedSearchText = searchText(item);
  }
  return item._cachedSearchText;
}

function relationScore(source, target) {
  const sourceWords = getKeywordsCached(source);
  const targetWords = getKeywordsCached(target);
  let score = 0;

  targetWords.forEach((word) => {
    if (sourceWords.has(word)) score += 3;
  });

  const sourceText = getSearchTextCached(source);
  const targetText = getSearchTextCached(target);

  if (source.type === 'drink' && target.ingredientType === 'coffee-bean' && /coffee|kopi|espresso|latte|cappuccino|mocha|americano|brew|macchiato|affogato/.test(sourceText)) score += 10;
  if (source.type === 'drink' && target.ingredientType === 'tea-leaf' && /tea|teh|matcha|chai|oolong|sencha|mate|terere|thai iced tea/.test(sourceText)) score += 10;
  if (target.type === 'drink' && source.ingredientType === 'coffee-bean' && /coffee|kopi|espresso|latte|cappuccino|mocha|americano|brew|macchiato|affogato/.test(targetText)) score += 10;
  if (target.type === 'drink' && source.ingredientType === 'tea-leaf' && /tea|teh|matcha|chai|oolong|sencha|mate|terere|thai iced tea/.test(targetText)) score += 10;
  if (sourceText.includes(String(target?.name || '').toLowerCase())) score += 7;
  if (targetText.includes(String(source?.name || '').toLowerCase())) score += 7;

  return score;
}

function pickRelated(source, targets, limit = 4) {
  if (!Array.isArray(targets)) return [];
  return targets
    .filter(Boolean)
    .map((target) => ({ target, score: relationScore(source, target) }))
    .filter((entry) => entry.score >= 6)
    .sort((left, right) => right.score - left.score || String(left.target?.name || '').localeCompare(String(right.target?.name || '')))
    .slice(0, limit)
    .map((entry) => entry.target.id);
}

function applySmartRelations(drinkItems = [], ingredientItems = []) {
  const normalizedDrinks = drinkItems.map((item) => ({ ...item }));
  const normalizedIngredients = ingredientItems.map((item) => ({ ...item }));

  normalizedDrinks.forEach((drink) => {
    if (!drink.relatedIngredientIds?.length) {
      const text = getSearchTextCached(drink);
      const isCoffeeDrink = /coffee|kopi|espresso|latte|cappuccino|mocha|americano|brew|macchiato|affogato|tubruk|turkish/.test(text);
      const isTeaDrink = /tea|teh|matcha|chai|oolong|sencha|mate|terere/.test(text);
      drink.relatedIngredientIds = (isCoffeeDrink || isTeaDrink) ? pickRelated(drink, normalizedIngredients, 4) : [];
    }
  });

  normalizedIngredients.forEach((ingredient) => {
    if (!ingredient.relatedDrinkIds?.length) {
      ingredient.relatedDrinkIds = pickRelated(ingredient, normalizedDrinks, 6);
    }
  });

  return { drinks: normalizedDrinks, ingredients: normalizedIngredients };
}

function resetToStaticCatalog() {
  const related = applySmartRelations(fallbackDrinks(), fallbackIngredients());
  drinks = related.drinks;
  ingredients = related.ingredients;
  allItems = sortByName([...drinks, ...ingredients]);
}

export async function ensureCatalogReady({ force = false } = {}) {
  if (catalogReadyPromise && !force) return catalogReadyPromise;

  catalogReadyPromise = Promise.all([
    fetchDrinksFromAPI(),
    fetchIngredientsFromAPI()
  ]).then(([fetchedDrinks, fetchedIngredients]) => {
    const related = applySmartRelations(fetchedDrinks, fetchedIngredients);
    drinks = related.drinks;
    ingredients = related.ingredients;
    allItems = sortByName([...drinks, ...ingredients]);
    return { drinks, ingredients, allItems, source: 'api-or-mock' };
  });

  return catalogReadyPromise;
}

export function normalizeItem(item, fallbackType = 'drink') {
  if (!item || typeof item !== 'object') return null;
  return {
    ...item,
    type: item?.type || fallbackType,
    // CRITICAL FIX: Pastikan kategori masuk ke ingredientType agar filter JS bisa baca
    ingredientType: item?.ingredientType || item?.category || '',
    // CRITICAL FIX: Pastikan asal masuk ke originRegion agar dropdown wilayah tidak kosong
    originRegion: item?.originRegion || item?.origin || 'Global',

    steps: toArray(item?.steps),
    tasteNotes: toArray(item?.tasteNotes),
    brewingTips: toArray(item?.brewingTips),
    relatedIngredientIds: toArray(item?.relatedIngredientIds),
    relatedDrinkIds: toArray(item?.relatedDrinkIds),
    likesCount: Number(item?.likesCount || 0),
    dislikesCount: Number(item?.dislikesCount || 0),
    imageUrl: item?.imageUrl || IMAGE_PLACEHOLDER,
    isPublished: item?.isPublished !== false,
  };
}

export function toArray(value) {
  if (Array.isArray(value)) return value.filter(Boolean);
  if (!value) return [];
  return String(value).split(/\r?\n|,|•|;/).map((part) => part.trim()).filter(Boolean);
}

export function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

export function qs(selector, scope = document) {
  return scope.querySelector(selector);
}

export function qsa(selector, scope = document) {
  return [...scope.querySelectorAll(selector)];
}

export function setText(selector, value) {
  const element = typeof selector === 'string' ? qs(selector) : selector;
  if (element) element.textContent = value;
}

export function debounce(callback, delay = 300) {
  let timeoutId;
  return (...args) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => callback(...args), delay);
  };
}

export function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

export function appendRuntimeFlag(url) {
  const rawUrl = String(url || '');
  if (!rawUrl || rawUrl.startsWith('#') || rawUrl.startsWith('http') || rawUrl.startsWith('mailto:') || rawUrl.startsWith('tel:')) {
    return url;
  }

  const currentParams = new URLSearchParams(window.location.search || '');
  const existingParams = new URLSearchParams(rawUrl.split('?')[1] || '');
  const flags = ['local', 'demo']
    .filter((key) => currentParams.get(key) === '1' && !existingParams.has(key))
    .map((key) => key + '=1');

  if (!flags.length) return url;
  return rawUrl + (rawUrl.includes('?') ? '&' : '?') + flags.join('&');
}

export function buildDetailUrl(item) {
  const isInsidePages = window.location.pathname.includes('/pages/') || window.location.href.includes('/pages/');
  const pagePrefix = isInsidePages ? '' : 'pages/';
  return appendRuntimeFlag(`${pagePrefix}detail.html?type=${encodeURIComponent(item.type || 'drink')}&id=${encodeURIComponent(item.id || '')}`);
}

export function itemTypeLabel(item) {
  if (!item) return 'Item';
  if (item?.type === 'drink') return 'Minuman';
  if (item?.ingredientType === 'coffee-bean') return 'Biji kopi';
  if (item?.ingredientType === 'tea-leaf') return 'Daun teh';
  return 'Ingredient';
}

function publicBasePath() {
  return window.location.pathname.includes('/pages/') ? '../' : '';
}

function looksLikeSearchPage(url = '') {
  const lower = url.toLowerCase();
  return lower.includes('google.com/search')
    || lower.includes('bing.com/search')
    || lower.includes('wikipedia.org/wiki/special:search');
}

function looksLikeImageUrl(url = '') {
  const lower = url.toLowerCase();
  return lower.startsWith('data:image/')
    || /\.(png|jpe?g|webp|gif|svg|avif)(\?|#|$)/.test(lower)
    || lower.includes('images.unsplash.com/')
    || lower.includes('images.pexels.com/')
    || lower.includes('cdn.pixabay.com/')
    || lower.includes('upload.wikimedia.org/')
    || lower.includes('commons.wikimedia.org/')
    || lower.includes('firebasestorage.googleapis.com/')
    || lower.includes('firebasestorage.app/')
    || lower.includes('lh3.googleusercontent.com/')
    || lower.includes('blogger.googleusercontent.com/')
    || lower.includes('raw.githubusercontent.com/')
    || lower.includes('githubusercontent.com/');
}

export function imageSrc(item) {
  const raw = String(item?.imageUrl || '').trim();

  if (!raw || looksLikeSearchPage(raw)) {
    return buildInlinePlaceholder(item?.name || 'DrinkQ');
  }

  if (raw.startsWith('http://') || raw.startsWith('https://') || raw.startsWith('data:')) {
    return looksLikeImageUrl(raw) ? raw : buildInlinePlaceholder(item?.name || 'DrinkQ');
  }

  if (raw.startsWith('blob:')) {
    return buildInlinePlaceholder(item?.name || 'DrinkQ');
  }

  const normalized = raw.replace(/^(\.\.\/|\.\/|\/)+/, '');
  if (normalized.startsWith('assets/')) {
    return `${publicBasePath()}${normalized}`;
  }

  if (normalized.startsWith('images/')) {
    return `${publicBasePath()}assets/${normalized}`;
  }

  if (/\.(png|jpe?g|webp|gif|svg|avif)(\?|#|$)/i.test(normalized)) {
    return `${publicBasePath()}${normalized}`;
  }

  return buildInlinePlaceholder(item?.name || 'DrinkQ');
}


export function safeExternalUrl(url = '') {
  const raw = String(url || '').trim();
  if (!raw || looksLikeSearchPage(raw)) return '';

  try {
    const parsed = new URL(raw, window.location.origin);
    if (!['https:', 'http:'].includes(parsed.protocol)) return '';
    return parsed.href;
  } catch {
    return '';
  }
}

export function tagList(tags = [], limit = 4) {
  return tags.slice(0, limit).map((tag) => `<span class="chip chip--soft">${escapeHtml(tag)}</span>`).join('');
}

const SEARCH_SYNONYMS = new Map([
  ['kopi', ['coffee', 'espresso', 'latte', 'brew', 'tubruk']],
  ['coffee', ['kopi', 'espresso', 'latte', 'brew']],
  ['teh', ['tea', 'matcha', 'chai', 'sencha', 'oolong']],
  ['tea', ['teh', 'matcha', 'chai', 'sencha', 'oolong']],
  ['susu', ['milk', 'latte', 'creamy', 'dairy']],
  ['milk', ['susu', 'latte', 'creamy', 'dairy']],
  ['dingin', ['iced', 'cold', 'fresh', 'refreshing']],
  ['cold', ['dingin', 'iced', 'fresh']],
  ['hangat', ['hot', 'warm', 'spiced']],
  ['hot', ['hangat', 'warm']],
  ['buah', ['fruit', 'juice', 'citrus', 'mango', 'orange']],
  ['fruit', ['buah', 'juice']],
  ['jepang', ['japan', 'japanese', 'matcha', 'sencha', 'sake']],
  ['japan', ['jepang', 'japanese', 'matcha', 'sencha', 'sake']],
  ['hijau', ['green', 'matcha', 'sencha']],
  ['green', ['hijau', 'matcha', 'sencha']],
  ['indonesia', ['indonesian', 'jamu', 'bajigur', 'bandrek', 'cendol', 'tubruk']],
  ['alkohol', ['alcohol', 'cocktail', 'wine', 'sake', 'soju']],
  ['nonalkohol', ['non-alcoholic', 'mocktail', 'virgin']],
  ['non', ['non-alcoholic', 'mocktail', 'virgin']],
  ['segar', ['fresh', 'refreshing', 'iced', 'citrus']],
  ['manis', ['sweet', 'creamy', 'dessert']],
  ['asam', ['sour', 'tart', 'citrus']]
]);

function normalizeSearchValue(value = '') {
  return String(value || '')
    .toLowerCase()
    .replace(/non[-\s]?alcoholic|non[-\s]?alkohol/g, 'nonalcoholic')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function expandSearchToken(token = '') {
  const normalized = normalizeSearchValue(token);
  const expansions = SEARCH_SYNONYMS.get(normalized) || [];
  return [normalized, ...expansions.map(normalizeSearchValue)].filter(Boolean);
}

function searchTokenGroups(value = '') {
  const normalizedQuery = normalizeSearchValue(value)
    .replace(/non\s+alkohol/g, 'nonalkohol')
    .replace(/non\s+alcoholic/g, 'nonalkohol');

  return normalizedQuery
    .split(/[\s-]+/)
    .map((token) => token.trim())
    .filter(Boolean)
    .map(expandSearchToken);
}

export function searchText(item) {
  if (!item) return '';
  return normalizeSearchValue([
    item.name,
    item.category,
    item.categoryLabel,
    item.ingredientType,
    item.ingredientTypeLabel,
    item.origin,
    item.originRegion,
    item.shortDescription,
    item.story,
    item.history,
    item.processingMethod,
    item.bodyLevel,
    ...toArray(item.tasteNotes),
    ...toArray(item.ingredients),
    ...toArray(item.steps),
    ...toArray(item.brewingTips),
  ].join(' '));
}

function scoreSearchEntry(entry, tokenGroups) {
  let matchedGroups = 0;
  const score = tokenGroups.reduce((total, group) => {
    const groupScore = group.reduce((best, token) => {
      if (!token) return best;
      if (entry.nameText === token) return Math.max(best, 24);
      if (entry.nameText.startsWith(token)) return Math.max(best, 18);
      if (entry.nameText.includes(token)) return Math.max(best, 14);
      if (entry.keywordSet.has(token)) return Math.max(best, 10);
      if (entry.text.includes(token)) return Math.max(best, 5);
      return best;
    }, 0);
    if (groupScore > 0) matchedGroups += 1;
    return total + groupScore;
  }, 0);

  const requiredGroups = tokenGroups.length <= 2 ? tokenGroups.length : tokenGroups.length - 1;
  return matchedGroups >= requiredGroups ? score : 0;
}

export function createSearchIndex(items = []) {
  if (!Array.isArray(items)) return [];
  return items.filter(Boolean).map((item) => {
    const text = searchText(item);
    const nameText = normalizeSearchValue(item?.name || '');
    return {
      item,
      text,
      nameText,
      keywordSet: new Set(text.split(/\s+/).filter(Boolean))
    };
  });
}

export function filterSearchIndex(index = [], query = '') {
  if (!Array.isArray(index)) return [];
  const tokenGroups = searchTokenGroups(query);
  if (!tokenGroups.length) return index.map((entry) => entry?.item).filter(Boolean);

  return index
    .filter(Boolean)
    .map((entry) => ({ entry, score: scoreSearchEntry(entry, tokenGroups) }))
    .filter(({ score }) => score > 0)
    .sort((left, right) => right.score - left.score || String(left.entry?.item?.name || '').localeCompare(String(right.entry?.item?.name || '')))
    .map(({ entry }) => entry.item);
}

export function getUniqueOptions(items, getter) {
  if (!Array.isArray(items)) return [];
  const map = new Map();
  items.filter(Boolean).forEach((item) => {
    const value = String(getter(item) || '').trim();
    if (!value) return;
    if (!map.has(value)) map.set(value, value);
  });
  return [...map.keys()].sort((a, b) => a.localeCompare(b));
}

export function renderItemCard(item, options = {}) {
  const meta = [itemTypeLabel(item), item?.origin || item?.originRegion || 'Global'].filter(Boolean).join(' • ');
  const description = item?.shortDescription || item?.story || 'Profil singkat item DrinkQ.';
  const imageClass = options?.compact ? 'card__image card__image--compact' : 'card__image';
  const score = Number(item?.likesCount || 0) - Number(item?.dislikesCount || 0);

  const actualImgSrc = imageSrc(item);
  const lazy = options?.lazy ?? true;
  const srcAttr = `src="${escapeHtml(actualImgSrc)}"`;
  const loadingAttr = lazy ? 'loading="lazy"' : 'loading="eager"';
  const lazyClass = 'lazy-img';
  
  const delayMs = (options?.delay ?? 0) * 50;
  const animationStyle = options?.staggered ? `style="animation-delay: ${delayMs}ms;"` : '';

  return `
    <article class="catalog-card reveal-on-scroll catalog-card--${escapeHtml(item?.type || 'item')} ${item?.ingredientType ? `catalog-card--${escapeHtml(item.ingredientType)}` : ''}" data-card-id="${escapeHtml(item?.id)}" data-item-type="${escapeHtml(item?.type || 'item')}" data-category="${escapeHtml(item?.category || item?.ingredientType || 'general')}" ${animationStyle}>
      <a class="catalog-card__media" href="${buildDetailUrl(item)}" aria-label="Buka detail ${escapeHtml(item?.name)}">
        <img class="${imageClass} ${lazyClass}" ${srcAttr} ${loadingAttr} onload="this.classList.add('loaded')" alt="Visual ${escapeHtml(item?.name)}" decoding="async" fetchpriority="low" width="800" height="600" data-fallback="${escapeHtml(item?.name)}" />
        <span class="media-pill">${escapeHtml(itemTypeLabel(item))}</span>
      </a>
      <div class="catalog-card__body">
        <p class="catalog-card__meta">${escapeHtml(meta)}</p>
        <h3>${escapeHtml(item?.name)}</h3>
        <p>${escapeHtml(description)}</p>
        <div class="chip-row">${tagList(item?.tasteNotes || [], 3)}</div>
        <div class="catalog-card__actions">
          <a class="button button--small" href="${buildDetailUrl(item)}" aria-label="Lihat detail ${escapeHtml(item?.name)}">Lihat detail</a>
          <span class="score-pill" title="Skor suka">${score >= 0 ? '+' : ''}${score}</span>
        </div>
      </div>
    </article>`;
}

export function renderEmpty(title = 'Tidak ada hasil', message = 'Coba ubah keyword atau reset filter.') {
  return `
    <div class="empty-state">
      <strong>${escapeHtml(title)}</strong>
      <span>${escapeHtml(message)}</span>
    </div>`;
}

export function attachImageFallbacks(scope = document) {
  qsa('img[data-fallback], img[data-fallback-label]', scope).forEach((img) => {
    if (img.dataset.boundFallback === 'true') return;
    img.dataset.boundFallback = 'true';
    img.decoding = img.decoding || 'async';
    if (!img.loading && !img.closest('.showcase-card')) img.loading = 'lazy';
    if (!img.getAttribute('width')) img.setAttribute('width', '800');
    if (!img.getAttribute('height')) img.setAttribute('height', '600');
    img.addEventListener('error', () => {
      if (img.dataset.usedInlineFallback === 'true') return;
      img.dataset.usedInlineFallback = 'true';
      img.src = buildInlinePlaceholder(img.dataset.fallback || img.dataset.fallbackLabel || img.alt || 'DrinkQ');
      img.classList.add('is-fallback');
    });
  });
}

export function randomItems(items, count = 6) {
  const copy = [...items];
  for (let index = copy.length - 1; index > 0; index -= 1) {
    const randomIndex = Math.floor(Math.random() * (index + 1));
    [copy[index], copy[randomIndex]] = [copy[randomIndex], copy[index]];
  }
  return copy.slice(0, count);
}

let gridObserver = null;

export const RenderEngine = {
  renderCatalogGrid(gridContainer, items, options = {}) {
    if (!gridContainer) return;

    const append = options.append ?? false;
    
    // Clean up observers on fresh render to prevent memory leaks
    if (!append) {
      if (gridObserver) {
        gridObserver.disconnect();
        gridObserver = null;
      }
      gridContainer.innerHTML = '';
    }

    if (!Array.isArray(items) || items.length === 0) {
      if (!append) {
        const temp = document.createElement('template');
        temp.innerHTML = renderEmpty(options.emptyTitle, options.emptyMessage);
        gridContainer.appendChild(temp.content);
      }
      return;
    }

    const temp = document.createElement('template');
    const cardsHtml = items.filter(Boolean).map((item, index) => {
      // For append mode, reset stagger delay so new items slide up gracefully and instantly!
      const delay = append ? index : (options.startIndex ?? 0) + index;
      return renderItemCard(item, {
        ...options,
        lazy: true,
        staggered: true,
        delay: delay
      });
    }).join('');

    temp.innerHTML = cardsHtml;
    const fragment = temp.content;

    // Append fragment to DOM first so images are active and visible in layout before observation
    gridContainer.appendChild(fragment);

    // Set up lazy-loading for newly inserted images AFTER attaching to active DOM
    RenderEngine.lazyLoadImages(gridContainer);

    // Bind fallbacks on new container elements
    attachImageFallbacks(gridContainer);

    // Refresh ScrollReveal if active
    if (window.DrinkQScrollReveal?.refresh) {
      window.DrinkQScrollReveal.refresh();
    }
  },

  lazyLoadImages(container) {
    // Native lazy loading is used with inline onload triggers.
    // This completes the transition if images are already cached on mount.
    container.querySelectorAll('.lazy-img').forEach(img => {
      if (img.complete) {
        img.classList.add('loaded');
      }
    });
  },

  renderSelectOptions(selectElement, optionsList, defaultOption = { value: 'all', text: 'Semua' }, currentValue = 'all') {
    if (!selectElement) return;
    const temp = document.createElement('template');
    const optionsHtml = `<option value="${escapeHtml(defaultOption.value)}">${escapeHtml(defaultOption.text)}</option>` +
      optionsList.map(value => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
    temp.innerHTML = optionsHtml;
    selectElement.innerHTML = '';
    selectElement.appendChild(temp.content);
    selectElement.value = currentValue;
  },

  renderSuggestions(suggestionsContainer, suggestionsList) {
    if (!suggestionsContainer) return;
    const temp = document.createElement('template');
    temp.innerHTML = suggestionsList.map(item => 
      `<button class="chip chip--soft" type="button" data-suggestion="${escapeHtml(item)}">${escapeHtml(item)}</button>`
    ).join('');
    suggestionsContainer.innerHTML = '';
    suggestionsContainer.appendChild(temp.content);
  },

  renderError(container, title = 'Terjadi kesalahan', message = 'Coba refresh halaman.') {
    if (!container) return;
    container.innerHTML = '';
    const temp = document.createElement('template');
    temp.innerHTML = `
      <div class="empty-state">
        <strong>${escapeHtml(title)}</strong>
        <span>${escapeHtml(message)}</span>
      </div>`;
    container.appendChild(temp.content);
  }
};
