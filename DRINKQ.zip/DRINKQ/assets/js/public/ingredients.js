import { 
  attachImageFallbacks, 
  createSearchIndex, 
  debounce, 
  filterSearchIndex, 
  getUniqueOptions, 
  ingredients, 
  setText, 
  escapeHtml, 
  ensureCatalogReady,
  RenderEngine,
  itemTypeValue
} from './catalog-data.js';

function getResponsiveBatchSize() {
  if (window.matchMedia?.('(max-width: 640px)').matches) return 10;
  if (window.matchMedia?.('(max-width: 1024px)').matches) return 14;
  return 18;
}

const BATCH_SIZE = getResponsiveBatchSize();
const state = { query: '', type: 'all', region: 'all', sort: 'name', visibleLimit: BATCH_SIZE };
let ingredientSearchIndex = [];

// Cache DOM references to avoid expensive querySelector operations inside performance-critical paths
const dom = {
  grid: null,
  searchInput: null,
  typeSelect: null,
  regionSelect: null,
  sortSelect: null,
  resetButton: null,
  beansCount: null,
  teaCount: null,
  totalCount: null,
  count: null,
  loadMoreButton: null
};

function initDOM() {
  dom.grid = document.querySelector('[data-grid]');
  dom.searchInput = document.querySelector('[data-search]');
  dom.typeSelect = document.querySelector('[data-type]');
  dom.regionSelect = document.querySelector('[data-region]');
  dom.sortSelect = document.querySelector('[data-sort]');
  dom.resetButton = document.querySelector('[data-reset]');
  dom.beansCount = document.querySelector('[data-beans-count]');
  dom.teaCount = document.querySelector('[data-tea-count]');
  dom.totalCount = document.querySelector('[data-total-count]');
  dom.count = document.querySelector('[data-count]');
}

// Update URL parameters dynamically for perfect state sync
function updateURL(query) {
  try {
    const params = new URLSearchParams(window.location.search);
    if (query) {
      params.set('q', query);
    } else {
      params.delete('q');
    }
    const newRelativePathQuery = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
    window.history.replaceState(null, '', newRelativePathQuery);
  } catch (e) {
    console.warn('Gagal sinkronisasi parameter URL:', e);
  }
}

// Simulasi pencarian API dengan paginasi
async function fetchIngredientsResults(state, limit, offset) {
  try {
    const params = new URLSearchParams({
      q: state.query || '',
      type: state.type || 'all',
      region: state.region || 'all',
      sort: state.sort || 'name',
      limit: String(limit || BATCH_SIZE),
      offset: String(offset || 0)
    });
    
    // Only attempt API if explicitly enabled via ?api=1 URL param
    if (!new URLSearchParams(window.location.search).has('api')) {
      throw new Error('Static mode, using local filtering.');
    }

    const response = await fetch(`/api/ingredients/search?${params.toString()}`);
    if (!response.ok) throw new Error('API Pencarian gagal');
    const data = (await response.json()) ?? {};
    // Fallback if API returns empty for a wildcard query
    if ((!data.items || data.items.length === 0) && !state.query) {
      throw new Error('API mengembalikan hasil kosong, gunakan data lokal');
    }
    return {
      items: data.items ?? [],
      total: data.total ?? 0
    };
  } catch (error) {
    // Fallback: Filter lokal dengan perlindungan optimal dari undefined
    const results = filterSearchIndex(ingredientSearchIndex, state.query)
      .filter((item) => {
        if (!item) return false;
        
        // Tipe filter wilayah
        if (state.region !== 'all') {
          const itemRegion = String(item.originRegion ?? item.origin ?? '').toLowerCase();
          if (itemRegion !== state.region.toLowerCase()) return false;
        }

        if (state.type === 'all') return true;
        const typeVal = itemTypeValue(item);
        return typeVal === state.type.toLowerCase();
      })
      .sort((a, b) => {
        if (!a || !b) return 0;
        const nameA = String(a.name || '');
        const nameB = String(b.name || '');
        if (state.sort === 'origin') {
          const originA = String(a.originRegion || a.origin || '');
          const originB = String(b.originRegion || b.origin || '');
          return originA.localeCompare(originB) || nameA.localeCompare(nameB);
        }
        if (state.sort === 'type') {
          const typeA = String(a.ingredientType || '');
          const typeB = String(b.ingredientType || '');
          return typeA.localeCompare(typeB) || nameA.localeCompare(nameB);
        }
        return nameA.localeCompare(nameB);
      });

    return {
      items: results.slice(offset, offset + limit),
      total: results.length
    };
  }
}

function renderOptions() {
  if (dom.regionSelect) {
    const list = getUniqueOptions(ingredients, (item) => item ? item.originRegion : '');
    RenderEngine.renderSelectOptions(dom.regionSelect, list, { value: 'all', text: 'Semua wilayah' }, state.region);
  }
}

function renderStats() {
  if (dom.beansCount) {
    dom.beansCount.textContent = ingredients.filter((item) => item && (item.ingredientType === 'coffee-bean' || String(item.ingredientType).toLowerCase().includes('coffee'))).length;
  }
  if (dom.teaCount) {
    dom.teaCount.textContent = ingredients.filter((item) => item && (item.ingredientType === 'tea-leaf' || String(item.ingredientType).toLowerCase().includes('tea'))).length;
  }
  if (dom.totalCount) {
    dom.totalCount.textContent = ingredients.length;
  }
}

function ensureLoadMoreButton() {
  if (!dom.grid) return null;
  if (dom.loadMoreButton) return dom.loadMoreButton;

  let button = document.querySelector('[data-load-more]');
  if (button) {
    dom.loadMoreButton = button;
    return button;
  }

  button = document.createElement('button');
  button.type = 'button';
  button.className = 'button button--primary catalog-load-more';
  button.dataset.loadMore = 'true';
  button.textContent = 'Muat lagi';
  button.addEventListener('click', handleLoadMore);
  dom.grid.insertAdjacentElement('afterend', button);
  dom.loadMoreButton = button;
  return button;
}

async function handleLoadMore() {
  if (dom.loadMoreButton) {
    dom.loadMoreButton.disabled = true;
    dom.loadMoreButton.textContent = 'Memuat...';
  }

  const currentRenderedCount = dom.grid?.querySelectorAll('.catalog-card').length ?? 0;
  const resultData = await fetchIngredientsResults(state, BATCH_SIZE, currentRenderedCount);
  const newItems = resultData.items || [];
  const totalItems = resultData.total || 0;

  // Append new items (zero layout shifts, zero DOM thrashing, preserves scroll position)
  RenderEngine.renderCatalogGrid(dom.grid, newItems, {
    append: true,
    startIndex: currentRenderedCount,
    emptyTitle: 'Ingredient tidak ditemukan',
    emptyMessage: 'Coba reset filter atau gunakan keyword lain.'
  });

  const finalRenderedCount = dom.grid?.querySelectorAll('.catalog-card').length ?? 0;
  state.visibleLimit = finalRenderedCount;

  updateLoadMoreUI(finalRenderedCount, totalItems);
}

function updateLoadMoreUI(renderedCount, totalItems) {
  if (dom.count) {
    dom.count.textContent = `${renderedCount} ditampilkan dari ${totalItems} hasil / ${ingredients.length} ingredient`;
  }

  const loadMoreButton = ensureLoadMoreButton();
  if (loadMoreButton) {
    loadMoreButton.disabled = false;
    loadMoreButton.hidden = renderedCount >= totalItems;
    loadMoreButton.textContent = `Muat lagi (${Math.min(BATCH_SIZE, Math.max(0, totalItems - renderedCount))})`;
  }
}

async function render(isInitial = false) {
  if (!dom.grid) return;

  if (isInitial) {
    state.visibleLimit = BATCH_SIZE;
  }

  const resultData = await fetchIngredientsResults(state, state.visibleLimit, 0);
  const visibleItems = resultData.items || [];
  const totalItems = resultData.total || 0;

  // Render first batch (append = false)
  RenderEngine.renderCatalogGrid(dom.grid, visibleItems, {
    append: false,
    startIndex: 0,
    emptyTitle: 'Ingredient tidak ditemukan',
    emptyMessage: 'Coba reset filter atau gunakan keyword lain.'
  });

  updateLoadMoreUI(visibleItems.length, totalItems);
}

function resetFilters() {
  state.query = '';
  state.type = 'all';
  state.region = 'all';
  state.sort = 'name';
  state.visibleLimit = BATCH_SIZE;
  
  if (dom.searchInput) dom.searchInput.value = '';
  if (dom.typeSelect) dom.typeSelect.value = 'all';
  if (dom.regionSelect) dom.regionSelect.value = 'all';
  if (dom.sortSelect) dom.sortSelect.value = 'name';
  
  updateURL('');
  renderOptions();
  render(true);
}

function renderLoadError(error) {
  console.error(error);
  if (dom.grid) {
    RenderEngine.renderError(dom.grid, 'Katalog bahan gagal dimuat', 'Coba refresh halaman. Jika masih error, buka dengan ?local=1 untuk memakai data lokal.');
  }
  if (dom.count) dom.count.textContent = 'Gagal memuat bahan';
}

window.addEventListener('DOMContentLoaded', async () => {
  let handleInput = null;
  let handleTypeChange = null;
  let handleRegionChange = null;
  let handleSortChange = null;
  let handleResetClick = null;
  let handlePopState = null;

  try {
    initDOM();
    await ensureCatalogReady();
    ingredientSearchIndex = createSearchIndex(ingredients);
    
    // Sync URL parameter if any
    const queryParam = new URLSearchParams(window.location.search).get('q');
    if (queryParam) {
      state.query = queryParam;
      if (dom.searchInput) dom.searchInput.value = queryParam;
    }

    renderOptions();
    renderStats();
    await render(true);

    handleInput = debounce(async (event) => {
      state.query = event.target.value.trim();
      updateURL(state.query);
      await render(true);
    }, 300);
    dom.searchInput?.addEventListener('input', handleInput);

    handleTypeChange = async (event) => {
      state.type = event.target.value;
      await render(true);
    };
    dom.typeSelect?.addEventListener('change', handleTypeChange);

    handleRegionChange = async (event) => {
      state.region = event.target.value;
      await render(true);
    };
    dom.regionSelect?.addEventListener('change', handleRegionChange);

    handleSortChange = async (event) => {
      state.sort = event.target.value;
      await render(true);
    };
    dom.sortSelect?.addEventListener('change', handleSortChange);

    handleResetClick = () => {
      resetFilters();
    };
    dom.resetButton?.addEventListener('click', handleResetClick);

    // Sync state on browser Back/Forward actions
    handlePopState = async () => {
      const q = new URLSearchParams(window.location.search).get('q') || '';
      state.query = q;
      if (dom.searchInput) dom.searchInput.value = q;
      await render(true);
    };
    window.addEventListener('popstate', handlePopState);

    // Clean up to eliminate memory leaks on page exit
    window.addEventListener('unload', () => {
      dom.searchInput?.removeEventListener('input', handleInput);
      dom.typeSelect?.removeEventListener('change', handleTypeChange);
      dom.regionSelect?.removeEventListener('change', handleRegionChange);
      dom.sortSelect?.removeEventListener('change', handleSortChange);
      dom.resetButton?.removeEventListener('click', handleResetClick);
      window.removeEventListener('popstate', handlePopState);
    }, { once: true });

  } catch (error) {
    renderLoadError(error);
  }
});