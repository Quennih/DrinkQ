import { allItems, appendRuntimeFlag, attachImageFallbacks, drinks, ingredients, escapeHtml, getParam, imageSrc, itemTypeLabel, renderItemCard, tagList, ensureCatalogReady, safeExternalUrl } from './catalog-data.js';
import { getDeviceId, showToast } from '../shared/utils.js';

const LOCAL_VOTE_KEY = 'drinkq_local_votes';

function readLocalVotes() {
  try {
    return JSON.parse(window.localStorage.getItem(LOCAL_VOTE_KEY) || '{}');
  } catch {
    return {};
  }
}

function writeLocalVotes(votes) {
  try {
    window.localStorage.setItem(LOCAL_VOTE_KEY, JSON.stringify(votes));
  } catch {
    // Voting lokal bersifat opsional; jangan sampai memblokir halaman detail.
  }
}

async function voteItemLocally({ itemId, voteType, deviceId }) {
  if (!itemId || !['like', 'dislike'].includes(voteType)) {
    throw new Error('Vote tidak valid.');
  }

  const voteKey = `${itemId}:${deviceId || 'local'}`;
  const votes = readLocalVotes();
  const previousVote = votes[voteKey];
  let likesDelta = 0;
  let dislikesDelta = 0;

  if (previousVote === voteType) {
    delete votes[voteKey];
    likesDelta = voteType === 'like' ? -1 : 0;
    dislikesDelta = voteType === 'dislike' ? -1 : 0;
  } else {
    votes[voteKey] = voteType;
    likesDelta = voteType === 'like' ? 1 : previousVote === 'like' ? -1 : 0;
    dislikesDelta = voteType === 'dislike' ? 1 : previousVote === 'dislike' ? -1 : 0;
  }

  writeLocalVotes(votes);
  return { likesDelta, dislikesDelta, activeVote: votes[voteKey] || '' };
}

function list(items = []) {
  return items.length ? `<ul class="detail-list">${items.map((item) => `<li>${escapeHtml(item)}</li>`).join('')}</ul>` : '<p class="muted">Belum ada data.</p>';
}

function quickFacts(item = {}) {
  const facts = [
    item.origin ? ['Asal', item.origin] : null,
    item.originRegion ? ['Wilayah', item.originRegion] : null,
    item.categoryLabel || item.ingredientTypeLabel ? ['Jenis', item.categoryLabel || item.ingredientTypeLabel] : null,
    item.processingMethod ? ['Proses', item.processingMethod] : null,
    item.bodyLevel ? ['Body', item.bodyLevel] : null,
    item.tasteNotes?.length ? ['Catatan rasa', item.tasteNotes.slice(0, 4).join(', ')] : null
  ].filter(Boolean);

  return facts.length
    ? `<dl class="fact-list">${facts.map(([label, value]) => `<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`).join('')}</dl>`
    : '<p class="muted">Belum ada fakta cepat.</p>';
}

function sharedTasteCount(left = {}, right = {}) {
  const leftTaste = new Set((left.tasteNotes || []).map((value) => String(value).toLowerCase()));
  return (right.tasteNotes || []).filter((value) => leftTaste.has(String(value).toLowerCase())).length;
}

function relatedItems(item) {
  if (item.type === 'drink') {
    const ingredientMatches = ingredients.filter((ingredient) => item.relatedIngredientIds?.includes(ingredient.id));
    const similarDrinks = drinks
      .filter((drink) => drink.id !== item.id)
      .map((drink) => ({
        item: drink,
        score: (drink.category === item.category ? 5 : 0)
          + (drink.originRegion && drink.originRegion === item.originRegion ? 2 : 0)
          + sharedTasteCount(item, drink)
      }))
      .filter((entry) => entry.score > 0)
      .sort((left, right) => right.score - left.score || String(left.item?.name || '').localeCompare(String(right.item?.name || '')))
      .map((entry) => entry.item);

    return [...ingredientMatches, ...similarDrinks]
      .filter((entry, index, list) => list.findIndex((candidate) => candidate.id === entry.id) === index)
      .slice(0, 4);
  }

  return drinks.filter((drink) => item.relatedDrinkIds?.includes(drink.id)).slice(0, 4);
}

function renderNotFound(container) {
  if (!container) return;
  container.innerHTML = `
    <div class="empty-state">
      <strong>Item tidak ditemukan</strong>
      <span>Link detail tidak cocok dengan data katalog.</span>
      <a class="button button--small" href="${appendRuntimeFlag('search.html')}">Cari item lain</a>
    </div>`;
}

function renderDetail(item) {
  const container = document.querySelector('[data-detail-content]');
  if (!container) return;
  const related = relatedItems(item);
  document.title = `${item.name} | DrinkQ`;
  container.innerHTML = `
    <article class="detail-layout">
      <div class="detail-media">
        <img src="${escapeHtml(imageSrc(item))}" alt="Visual ${escapeHtml(item.name)}" loading="eager" decoding="async" fetchpriority="high" width="900" height="900" data-fallback="${escapeHtml(item.name)}" />
      </div>
      <div class="detail-main">
        <a class="text-link" href="${appendRuntimeFlag(item.type === 'drink' ? 'drinks.html' : 'ingredients.html')}">← Kembali</a>
        <p class="catalog-card__meta">${escapeHtml(itemTypeLabel(item))} • ${escapeHtml(item.origin || item.originRegion || 'Global')}</p>
        <h1>${escapeHtml(item.name)}</h1>
        <p class="lead">${escapeHtml(item.shortDescription || item.story || '')}</p>
        <div class="chip-row">${tagList(item.tasteNotes || [], 8)}</div>
        <div class="detail-actions">
          <a class="button button--small" href="${appendRuntimeFlag(`search.html?q=${encodeURIComponent(item.name)}`)}">Cari terkait</a>
          ${safeExternalUrl(item.sourceUrl) ? `<a class="button button--small button--ghost" href="${escapeHtml(safeExternalUrl(item.sourceUrl))}" target="_blank" rel="noopener noreferrer">Sumber referensi</a>` : ''}
        </div>
        <div class="vote-panel" data-vote-panel>
          <button class="button button--small button--ghost" type="button" data-vote="like">👍 Suka <span data-like-count>${Number(item.likesCount || 0)}</span></button>
          <button class="button button--small button--ghost" type="button" data-vote="dislike">👎 Kurang <span data-dislike-count>${Number(item.dislikesCount || 0)}</span></button>
        </div>
      </div>
    </article>
    <section class="detail-grid detail-grid--rich">
      <article class="detail-card detail-card--wide"><h2>Cerita singkat</h2><p>${escapeHtml(item.story || item.history || item.shortDescription || 'Belum ada cerita.')}</p></article>
      <article class="detail-card"><h2>Fakta cepat</h2>${quickFacts(item)}</article>
      <article class="detail-card detail-card--wide"><h2>Sejarah / asal</h2><p>${escapeHtml(item.history || item.origin || 'Belum ada data sejarah.')}</p></article>
      <article class="detail-card"><h2>${item.type === 'drink' ? 'Bahan utama' : 'Catatan rasa'}</h2>${item.type === 'drink' ? list(item.ingredients) : list(item.tasteNotes)}</article>
      <article class="detail-card"><h2>${item.type === 'drink' ? 'Langkah dasar' : 'Tips seduh'}</h2>${item.type === 'drink' ? list(item.steps) : list(item.brewingTips)}</article>
    </section>
    ${related.length ? `<section class="section section--embedded"><div class="section-heading section-heading--inline"><div><span class="eyebrow">Related</span><h2>Item terkait</h2></div></div><div class="catalog-grid">${related.map((entry) => renderItemCard(entry)).join('')}</div></section>` : ''}`;
  attachImageFallbacks(container);
}

function bindVoteActions(item) {
  const panel = document.querySelector('[data-vote-panel]');
  if (!panel) return;

  panel.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-vote]');
    if (!button) return;

    try {
      button.disabled = true;
      button.setAttribute('aria-busy', 'true');
      const updated = await voteItemLocally({
        itemId: item.id,
        voteType: button.dataset.vote,
        deviceId: getDeviceId()
      });

      item.likesCount = Math.max(0, Number(item.likesCount || 0) + Number(updated.likesDelta || 0));
      item.dislikesCount = Math.max(0, Number(item.dislikesCount || 0) + Number(updated.dislikesDelta || 0));
      panel.querySelectorAll('[data-vote]').forEach((entry) => entry.classList.remove('is-active'));
      if (updated.activeVote) {
        panel.querySelector(`[data-vote="${updated.activeVote}"]`)?.classList.add('is-active');
      }
      const likeCount = document.querySelector('[data-like-count]');
      const dislikeCount = document.querySelector('[data-dislike-count]');
      if (likeCount) likeCount.textContent = item.likesCount;
      if (dislikeCount) dislikeCount.textContent = item.dislikesCount;
    } catch (error) {
      console.error(error);
      showToast(error.message || 'Vote gagal disimpan secara lokal.', 'error');
    } finally {
      button.disabled = false;
      button.removeAttribute('aria-busy');
    }
  });
}

function renderLoadError(container, error) {
  console.error(error);
  if (!container) return;
  container.innerHTML = `
    <div class="empty-state">
      <strong>Detail gagal dimuat</strong>
      <span>Coba refresh halaman. Jika masih error, buka katalog melalui mode lokal dengan ?local=1.</span>
      <a class="button button--small" href="${appendRuntimeFlag('search.html')}">Kembali ke pencarian</a>
    </div>`;
}

window.addEventListener('DOMContentLoaded', async () => {
  const container = document.querySelector('[data-detail-content]');
  try {
    await ensureCatalogReady();
    const id = getParam('id');
    const type = getParam('type');
    
    let item;
    try {
      // Only attempt API if explicitly enabled via ?api=1 URL param
      if (!new URLSearchParams(window.location.search).has('api')) {
        throw new Error('Static mode, using local data.');
      }
      const response = await fetch(`/api/items/${id}?type=${type || ''}`);
      if (!response.ok) throw new Error('API Item tidak ditemukan');
      item = await response.json();
    } catch (apiError) {
      // Fallback menggunakan data lokal
      item = allItems.find((entry) => entry.id === id && (!type || entry.type === type));
    }
    if (!item) {
      renderNotFound(container);
      return;
    }
    renderDetail(item);
    bindVoteActions(item);
  } catch (error) {
    renderLoadError(container, error);
  }
});