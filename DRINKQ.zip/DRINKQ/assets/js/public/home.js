import { attachImageFallbacks, buildDetailUrl, drinks, ingredients, randomItems, renderEmpty, renderItemCard, setText, escapeHtml, imageSrc, ensureCatalogReady, RenderEngine } from './catalog-data.js';

const moods = [
  { label: 'Coffee', terms: ['coffee', 'kopi', 'espresso', 'latte'] },
  { label: 'Tea', terms: ['tea', 'teh', 'matcha', 'chai'] },
  { label: 'Fresh', terms: ['fresh', 'refreshing', 'juice', 'lemon', 'water'] },
  { label: 'Creamy', terms: ['creamy', 'milk', 'chocolate', 'shake'] },
  { label: 'Classic', terms: ['classic', 'traditional', 'coffee', 'tea'] },
];

function itemHaystack(item) {
  return [item.name, item.category, item.categoryLabel, item.shortDescription, item.origin, ...(item.tasteNotes || [])].join(' ').toLowerCase();
}

const FEATURE_STORAGE_KEY = 'drinkq:last-home-feature-id';

function safeGetLastFeatureId() {
  try {
    return window.localStorage?.getItem(FEATURE_STORAGE_KEY) || '';
  } catch {
    return '';
  }
}

function safeSetLastFeatureId(id) {
  try {
    return window.localStorage?.setItem(FEATURE_STORAGE_KEY, id);
  } catch {
    // Browser privacy mode can block storage; randomization still works without it.
  }
}

function pickRandomFeature() {
  const available = drinks.filter((item) => item?.id && item?.name);
  if (!available.length) return null;

  const lastFeatureId = safeGetLastFeatureId();
  const candidates = available.length > 1 ? available.filter((item) => item.id !== lastFeatureId) : available;
  const [feature] = randomItems(candidates.length ? candidates : available, 1);
  if (feature?.id) safeSetLastFeatureId(feature.id);
  return feature || available[0];
}

function renderHero() {
  const feature = pickRandomFeature();
  const hero = document.querySelector('[data-hero-feature]');
  const minis = document.querySelector('[data-hero-minis]');

  if (hero && feature) {
    hero.innerHTML = `
      <img class="reveal-on-scroll" src="${escapeHtml(imageSrc(feature))}" alt="${escapeHtml(feature.name)}" loading="eager" decoding="async" fetchpriority="high" width="900" height="700" data-fallback="${escapeHtml(feature.name)}" />
      <div class="reveal-on-scroll">
        <span class="eyebrow">${escapeHtml(feature.categoryLabel || feature.origin || 'DrinkQ')}</span>
        <h2 class="text-hero">${escapeHtml(feature.name)}</h2>
        <p class="lead">${escapeHtml(feature.shortDescription || 'Minuman pilihan acak dari katalog DrinkQ.')}</p>
        <div class="hero-actions">
          <a class="button" href="${buildDetailUrl(feature)}">
            Buka detail
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
          </a>
        </div>
      </div>`;
  }

  if (minis) {
    const miniSource = drinks.filter((item) => item.id !== feature?.id);
    minis.innerHTML = miniSource.slice(0, 3).map((item) => `
      <a class="mini-card reveal-on-scroll" href="${buildDetailUrl(item)}">
        <img src="${escapeHtml(imageSrc(item))}" alt="${escapeHtml(item.name)}" loading="lazy" decoding="async" fetchpriority="low" width="800" height="600" data-fallback="${escapeHtml(item.name)}" />
        <div>
          <span>${escapeHtml(item.categoryLabel || 'Drink')}</span>
          <strong>${escapeHtml(item.name)}</strong>
        </div>
      </a>`).join('');
  }

  attachImageFallbacks(document);
  if (window.DrinkQScrollReveal?.refresh) {
    window.DrinkQScrollReveal.refresh();
  }
}

function renderMoods(activeMood = moods[0]) {
  const tabs = document.querySelector('[data-mood-tabs]');
  const results = document.querySelector('[data-mood-results]');
  if (!tabs || !results) return;
  tabs.innerHTML = moods.map((mood) => `<button class="chip ${mood.label === activeMood.label ? 'is-active' : ''}" type="button" aria-pressed="${mood.label === activeMood.label}" data-mood-name="${escapeHtml(mood.label)}">${escapeHtml(mood.label)}</button>`).join('');
  const filtered = drinks.filter((item) => activeMood.terms.some((term) => itemHaystack(item).includes(term))).slice(0, 6);
  
  RenderEngine.renderCatalogGrid(results, filtered.length ? filtered : drinks.slice(0, 6));
}

function renderLoadError(error) {
  console.error(error);
  const moodResults = document.querySelector('[data-mood-results]');
  const featured = document.querySelector('[data-featured-grid]');
  const message = renderEmpty('Data gagal dimuat', 'Coba refresh halaman. Jika masih error, buka dengan ?local=1 untuk memakai data lokal.');
  if (moodResults) moodResults.innerHTML = message;
  if (featured) featured.innerHTML = message;
}

/**
 * Dismiss the splash screen programmatically, tied to data-readiness.
 * Clears the safety fallback timer set in index.html's inline script.
 */
function dismissSplash() {
  const splash = document.getElementById('splash-screen');
  if (!splash || splash.style.display === 'none' || splash.classList.contains('is-hidden')) return;

  // Cancel the HTML-inline fallback timer
  if (typeof window.__drinkqSplashFallback !== 'undefined') {
    clearTimeout(window.__drinkqSplashFallback);
  }

  splash.classList.add('is-hidden');
  splash.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('no-scroll');

  // Fire event so site-shell.js knows to add page-loaded class
  document.dispatchEvent(new CustomEvent('drinkq:splashDone'));

  // Remove from DOM after exit animation
  setTimeout(() => { splash.style.display = 'none'; }, 800);
}

window.addEventListener('DOMContentLoaded', async () => {
  try {
    await ensureCatalogReady();
    dismissSplash(); // Poin 4: dismiss tepat saat data siap

    const beansCount = ingredients.filter((item) => item.ingredientType === 'coffee-bean').length;
    const teasCount = ingredients.filter((item) => item.ingredientType === 'tea-leaf').length;
    setText('[data-total-drinks]', drinks.length);
    setText('[data-total-beans]', beansCount);
    setText('[data-total-teas]', teasCount);
    setText('[data-total-items]', drinks.length + ingredients.length);
    setText('[data-hero-drinks]', drinks.length);
    setText('[data-hero-beans]', beansCount);
    setText('[data-hero-teas]', teasCount);
    renderHero();
    document.querySelector('[data-reroll-feature]')?.addEventListener('click', renderHero);
    renderMoods(moods[0]);
    document.querySelector('[data-mood-tabs]')?.addEventListener('click', (event) => {
      const button = event.target.closest('[data-mood-name]');
      if (!button) return;
      const mood = moods.find((item) => item.label === button.dataset.moodName) || moods[0];
      renderMoods(mood);
    });
    const featured = document.querySelector('[data-featured-grid]');
    if (featured) {
      const featuredItems = drinks.filter((item) => item.featured);
      const items = (featuredItems.length >= 8 ? featuredItems : drinks).slice(0, 8);
      RenderEngine.renderCatalogGrid(featured, items, {
        emptyTitle: 'Belum ada minuman pilihan',
        emptyMessage: 'Data pilihan belum tersedia di katalog publik.'
      });
    }
  } catch (error) {
    renderLoadError(error);
    dismissSplash(); // Splash tidak boleh nyangkut walau error
  }
});