import { attachImageFallbacks, buildDetailUrl, createSearchIndex, debounce, drinks, escapeHtml, filterSearchIndex, getUniqueOptions, imageSrc, renderEmpty, renderItemCard, searchText, setText, tagList, ensureCatalogReady, RenderEngine } from './catalog-data.js';

function getResponsiveBatchSize() {
  if (window.matchMedia?.('(max-width: 640px)').matches) return 10;
  if (window.matchMedia?.('(max-width: 1024px)').matches) return 14;
  return 18;
}

const BATCH_SIZE = getResponsiveBatchSize();
const state = { query: '', category: 'all', region: 'all', sort: 'name', mood: 'all', compact: false, visibleLimit: BATCH_SIZE };
const moodOptions = ['all', 'coffee', 'tea', 'fresh', 'creamy', 'classic'];
let drinkSearchIndex = [];

function matchesMood(item) {
  if (state.mood === 'all') return true;
  const text = searchText(item);
  const map = {
    coffee: ['coffee', 'kopi', 'espresso', 'latte'],
    tea: ['tea', 'teh', 'matcha', 'chai'],
    fresh: ['fresh', 'refreshing', 'juice', 'lemon', 'water'],
    creamy: ['creamy', 'milk', 'chocolate', 'shake'],
    classic: ['classic', 'traditional', 'coffee', 'tea'],
  };
  return (map[state.mood] || []).some((term) => text.includes(term));
}

// Simulasi pencarian API dengan paginasi
async function fetchDrinksResults(state) {
  try {
    // Only attempt API if explicitly enabled via ?api=1 URL param
    if (!new URLSearchParams(window.location.search).has('api')) {
      throw new Error('Static mode, using local filtering.');
    }
    const params = new URLSearchParams({
      q: state.query,
      category: state.category,
      region: state.region,
      sort: state.sort,
      mood: state.mood,
      limit: state.visibleLimit,
      offset: 0
    });
    const response = await fetch(`/api/drinks/search?${params.toString()}`);
    if (!response.ok) throw new Error('API Pencarian gagal');
    return await response.json();
  } catch (error) {
    // Fallback: Filter lokal
    const results = filterSearchIndex(drinkSearchIndex, state.query)
      .filter((item) => state.category === 'all' || item.category === state.category)
      .filter((item) => state.region === 'all' || item.originRegion === state.region)
      .filter(matchesMood)
      .sort((a, b) => {
        if (state.sort === 'origin') return String(a.origin || '').localeCompare(String(b.origin || ''));
        if (state.sort === 'popular') return (b.likesCount - b.dislikesCount) - (a.likesCount - a.dislikesCount);
        return a.name.localeCompare(b.name);
      });
    
    return {
      items: results.slice(0, state.visibleLimit),
      total: results.length,
      allFiltered: results
    };
  }
}

function renderOptions() {
  const category = document.querySelector('[data-category]');
  if (category) {
    const values = [...new Map(drinks.map((item) => [item.category, item.categoryLabel || item.category])).entries()].filter(([value]) => value);
    category.innerHTML = '<option value="all">Semua kategori</option>' + values.sort((a, b) => a[1].localeCompare(b[1])).map(([value, label]) => `<option value="${escapeHtml(value)}">${escapeHtml(label)}</option>`).join('');
    category.value = state.category;
  }
  const region = document.querySelector('[data-region]');
  if (region) {
    region.innerHTML = '<option value="all">Semua wilayah</option>' + getUniqueOptions(drinks, (item) => item.originRegion).map((value) => `<option value="${escapeHtml(value)}">${escapeHtml(value)}</option>`).join('');
    region.value = state.region;
  }
  const mood = document.querySelector('[data-mood]');
  if (mood) {
    mood.innerHTML = moodOptions.map((value) => `<button type="button" class="chip ${value === state.mood ? 'is-active' : ''}" aria-pressed="${value === state.mood}" data-mood-value="${value}">${value === 'all' ? 'Semua' : escapeHtml(value)}</button>`).join('');
  }
}

function renderSpotlight(items) {
  const spotlight = document.querySelector('[data-spotlight]');
  if (!spotlight) return;
  const item = items[0] || drinks[0];
  if (!item) { spotlight.innerHTML = ''; return; }
  spotlight.innerHTML = `
    <img src="${escapeHtml(imageSrc(item))}" alt="${escapeHtml(item.name)}" loading="lazy" decoding="async" fetchpriority="low" width="800" height="600" data-fallback="${escapeHtml(item.name)}" />
    <div>
      <span class="eyebrow">Preview pilihan</span>
      <h2>${escapeHtml(item.name)}</h2>
      <p>${escapeHtml(item.shortDescription || item.story || '')}</p>
      <div class="chip-row">${tagList(item.tasteNotes || [], 4)}</div>
      <a class="button button--small" href="${buildDetailUrl(item)}">Baca detail</a>
    </div>`;
  attachImageFallbacks(spotlight);
}

function ensureLoadMoreButton(grid) {
  let button = document.querySelector('[data-load-more]');
  if (button) return button;

  button = document.createElement('button');
  button.type = 'button';
  button.className = 'button button--primary catalog-load-more';
  button.dataset.loadMore = 'true';
  button.textContent = 'Muat lagi';
  button.addEventListener('click', handleLoadMore);
  grid.insertAdjacentElement('afterend', button);
  return button;
}

async function handleLoadMore() {
  const grid = document.querySelector('[data-grid]');
  const button = document.querySelector('[data-load-more]');
  if (!grid) return;
  
  if (button) {
    button.disabled = true;
    button.textContent = 'Memuat...';
  }

  const currentRenderedCount = grid.querySelectorAll('.catalog-card').length;
  // Temporarily adjust state to fetch only the next batch offset
  const originalLimit = state.visibleLimit;
  state.visibleLimit = currentRenderedCount + BATCH_SIZE;
  
  const resultData = await fetchDrinksResults(state);
  const totalItems = resultData.total;
  
  // Extract just the new items by slicing the result from current count
  const newItems = resultData.items.slice(currentRenderedCount);

  RenderEngine.renderCatalogGrid(grid, newItems, {
    compact: state.compact,
    append: true,
    startIndex: currentRenderedCount,
    emptyTitle: 'Minuman tidak ditemukan',
    emptyMessage: 'Coba reset filter atau pakai keyword yang lebih umum.'
  });

  const finalRenderedCount = grid.querySelectorAll('.catalog-card').length;
  
  setText('[data-count]', `${finalRenderedCount} ditampilkan dari ${totalItems} hasil / ${drinks.length} minuman`);
  
  if (button) {
    button.disabled = false;
    button.hidden = finalRenderedCount >= totalItems;
    button.textContent = `Muat lagi (${Math.min(BATCH_SIZE, Math.max(0, totalItems - finalRenderedCount))})`;
  }
  
  window.DrinkQScrollReveal?.refresh();
}

async function render(isInitial = false) {
  const grid = document.querySelector('[data-grid]');
  if (!grid) return;
  
  if (isInitial) {
    state.visibleLimit = BATCH_SIZE;
  }
  
  const resultData = await fetchDrinksResults(state);
  const visibleItems = resultData.items;
  const totalItems = resultData.total;
  
  const loadMoreButton = ensureLoadMoreButton(grid);

  setText('[data-count]', `${visibleItems.length} ditampilkan dari ${totalItems} hasil / ${drinks.length} minuman`);
  renderSpotlight(resultData.allFiltered || visibleItems);
  
  grid.classList.toggle('catalog-grid--compact', state.compact);
  
  RenderEngine.renderCatalogGrid(grid, visibleItems, {
    compact: state.compact,
    append: false,
    startIndex: 0,
    emptyTitle: 'Minuman tidak ditemukan',
    emptyMessage: 'Coba reset filter atau pakai keyword yang lebih umum.'
  });
  
  loadMoreButton.hidden = visibleItems.length >= totalItems;
  loadMoreButton.textContent = `Muat lagi (${Math.min(BATCH_SIZE, Math.max(0, totalItems - visibleItems.length))})`;
  attachImageFallbacks(grid);
  window.DrinkQScrollReveal?.refresh();
}

function resetFilters() {
  state.query = '';
  state.category = 'all';
  state.region = 'all';
  state.sort = 'name';
  state.mood = 'all';
  state.visibleLimit = BATCH_SIZE;
  const search = document.querySelector('[data-search]');
  if (search) search.value = '';
  const sort = document.querySelector('[data-sort]');
  if (sort) sort.value = 'name';
  renderOptions();
  render(true);
}

function renderLoadError(error) {
  console.error(error);
  const grid = document.querySelector('[data-grid]');
  if (grid) {
    grid.innerHTML = renderEmpty('Katalog gagal dimuat', 'Coba refresh halaman. Jika masih error, buka dengan ?local=1 untuk memakai data lokal.');
  }
  setText('[data-count]', 'Gagal memuat minuman');
}

window.addEventListener('DOMContentLoaded', async () => {
  try {
    await ensureCatalogReady();
    drinkSearchIndex = createSearchIndex(drinks);
    renderOptions();
    render(true);
    document.querySelector('[data-search]')?.addEventListener('input', debounce(async (event) => { state.query = event.target.value.trim(); state.visibleLimit = BATCH_SIZE; await render(true); }, 120));
    document.querySelector('[data-category]')?.addEventListener('change', async (event) => { state.category = event.target.value; state.visibleLimit = BATCH_SIZE; await render(true); });
    document.querySelector('[data-region]')?.addEventListener('change', async (event) => { state.region = event.target.value; state.visibleLimit = BATCH_SIZE; await render(true); });
    document.querySelector('[data-sort]')?.addEventListener('change', async (event) => { state.sort = event.target.value; state.visibleLimit = BATCH_SIZE; await render(true); });
    document.querySelector('[data-reset]')?.addEventListener('click', resetFilters);
    document.querySelector('[data-random]')?.addEventListener('click', () => { const item = drinks[Math.floor(Math.random() * drinks.length)]; if (item) window.location.href = buildDetailUrl(item); });
    document.querySelector('[data-mood]')?.addEventListener('click', async (event) => { const button = event.target.closest('[data-mood-value]'); if (!button) return; state.mood = button.dataset.moodValue; state.visibleLimit = BATCH_SIZE; renderOptions(); await render(true); });
    document.querySelector('.view-toggle')?.addEventListener('click', async (event) => { const button = event.target.closest('[data-view]'); if (!button) return; state.compact = button.dataset.view === 'compact'; document.querySelectorAll('[data-view]').forEach((el) => { const active = el === button; el.classList.toggle('is-active', active); el.setAttribute('aria-pressed', String(active)); }); await render(true); });
  } catch (error) {
    renderLoadError(error);
  }
});