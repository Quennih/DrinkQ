// DrinkQ static drinks database.
// DrinkQ static encyclopedia database.
// Generated from the curated public catalog; keep this file static-safe for GitHub Pages, Netlify, and Firebase Hosting.

export const importedDrinks = [
  {
    "id": "drink-water",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Water",
    "slug": "water",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Air minum adalah minuman paling dasar dalam sejarah manusia dan selalu menjadi fondasi kehidupan di semua peradaban.",
    "story": "Air minum adalah minuman paling dasar dalam sejarah manusia dan selalu menjadi fondasi kehidupan di semua peradaban. Dalam katalog DrinkQ, Water ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Water memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Water menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Air bersih",
      "Es batu opsional"
    ],
    "steps": [
      "Minum langsung setelah disaring/didinginkan.",
      "Untuk sajian meja biasanya disajikan dingin atau dengan es."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/water.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Drinking_water",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-tea",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Tea",
    "slug": "tea",
    "origin": "China",
    "originRegion": "Asia",
    "shortDescription": "Teh umumnya ditelusuri ke Tiongkok kuno lalu menyebar ke Asia, Timur Tengah, dan Eropa melalui perdagangan.",
    "story": "Teh umumnya ditelusuri ke Tiongkok kuno lalu menyebar ke Asia, Timur Tengah, dan Eropa melalui perdagangan. Dalam katalog DrinkQ, Tea ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada tea-based, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Tea memiliki konteks asal yang berkaitan dengan China. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Tea menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Seduh daun teh dengan air panas 2–5 menit, lalu saring.",
      "Bisa diminum polos atau ditambah gula/madu."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/tea.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Tea",
    "relatedIngredientIds": [
      "ingredient-green-tea",
      "ingredient-black-tea",
      "ingredient-oolong-tea"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "China",
    "isPublished": true
  },
  {
    "id": "drink-coffee",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Coffee",
    "slug": "coffee",
    "origin": "Ethiopia/Yemen",
    "originRegion": "Africa",
    "shortDescription": "Kopi berasal dari Afrika Timur dan berkembang besar di Yaman sebelum menyebar ke dunia lewat jalur dagang Arab dan kolonial.",
    "story": "Kopi berasal dari Afrika Timur dan berkembang besar di Yaman sebelum menyebar ke dunia lewat jalur dagang Arab dan kolonial. Dalam katalog DrinkQ, Coffee ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Coffee memiliki konteks asal yang berkaitan dengan Ethiopia/Yemen. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Coffee menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Seduh kopi giling dengan air panas memakai metode seperti tubruk, pour over, French press, atau espresso."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/coffee.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Coffee",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Ethiopia/Yemen",
    "isPublished": true
  },
  {
    "id": "drink-hot-chocolate",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Hot Chocolate",
    "slug": "hot-chocolate",
    "origin": "Mesoamerica/Europe",
    "originRegion": "Europe",
    "shortDescription": "Cokelat panas berakar dari minuman kakao Mesoamerika, lalu diadaptasi Eropa menjadi versi manis dan creamy.",
    "story": "Cokelat panas berakar dari minuman kakao Mesoamerika, lalu diadaptasi Eropa menjadi versi manis dan creamy. Dalam katalog DrinkQ, Hot Chocolate ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada creamy, Sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Hot Chocolate memiliki konteks asal yang berkaitan dengan Mesoamerica/Europe. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Hot Chocolate menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kakao/cokelat",
      "Susu atau air",
      "Gula opsional"
    ],
    "steps": [
      "Panaskan susu/air, campur bubuk kakao atau cokelat, gula, lalu aduk hingga larut."
    ],
    "tasteNotes": [
      "Creamy",
      "Sparkling",
      "Refreshing"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/hot-chocolate.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Hot_chocolate",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Mesoamerica/Europe",
    "isPublished": true
  },
  {
    "id": "drink-milk",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Milk",
    "slug": "milk",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Susu telah dikonsumsi sejak awal domestikasi hewan ternak dan menjadi bahan penting banyak budaya.",
    "story": "Susu telah dikonsumsi sejak awal domestikasi hewan ternak dan menjadi bahan penting banyak budaya. Dalam katalog DrinkQ, Milk ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Milk memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Milk menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Susu segar",
      "Es atau pemanis opsional"
    ],
    "steps": [
      "Sajikan dingin, hangat, atau dipasteurisasi sesuai kebutuhan."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/milk.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Milk",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-orange-juice",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Orange Juice",
    "slug": "orange-juice",
    "origin": "Mediterranean/Americas",
    "originRegion": "Americas",
    "shortDescription": "Jus jeruk menjadi populer luas pada era modern seiring kemajuan budidaya jeruk dan industri sarapan.",
    "story": "Jus jeruk menjadi populer luas pada era modern seiring kemajuan budidaya jeruk dan industri sarapan. Dalam katalog DrinkQ, Orange Juice ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Orange Juice memiliki konteks asal yang berkaitan dengan Mediterranean/Americas. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Orange Juice menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Jeruk segar",
      "Es opsional"
    ],
    "steps": [
      "Peras jeruk segar, saring bila perlu, lalu sajikan dingin."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/orange-juice.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Orange_juice",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Mediterranean/Americas",
    "isPublished": true
  },
  {
    "id": "drink-lemonade",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Lemonade",
    "slug": "lemonade",
    "origin": "Europe/Middle East",
    "originRegion": "Europe",
    "shortDescription": "Lemonade telah lama dikenal sebagai minuman segar berbasis lemon, dengan banyak variasi lokal di dunia.",
    "story": "Lemonade telah lama dikenal sebagai minuman segar berbasis lemon, dengan banyak variasi lokal di dunia. Dalam katalog DrinkQ, Lemonade ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Lemonade memiliki konteks asal yang berkaitan dengan Europe/Middle East. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Lemonade menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Air lemon",
      "Air mineral",
      "Gula atau madu",
      "Es batu"
    ],
    "steps": [
      "Campur air, air lemon, dan gula.",
      "Aduk lalu sajikan dengan es."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/lemonade.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Lemonade",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Europe/Middle East",
    "isPublished": true
  },
  {
    "id": "drink-apple-juice",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Apple Juice",
    "slug": "apple-juice",
    "origin": "Europe/North America",
    "originRegion": "Americas",
    "shortDescription": "Jus apel berkembang dari budaya konsumsi apel di Eropa dan Amerika serta industri pengolahan buah.",
    "story": "Jus apel berkembang dari budaya konsumsi apel di Eropa dan Amerika serta industri pengolahan buah. Dalam katalog DrinkQ, Apple Juice ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Apple Juice memiliki konteks asal yang berkaitan dengan Europe/North America. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Apple Juice menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender/peras apel, saring, lalu sajikan dingin."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/apple-juice.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Apple_juice",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Europe/North America",
    "isPublished": true
  },
  {
    "id": "drink-grape-juice",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Grape Juice",
    "slug": "grape-juice",
    "origin": "Mediterranean/Global",
    "originRegion": "Global",
    "shortDescription": "Jus anggur berasal dari wilayah budidaya anggur kuno dan menjadi alternatif non-alkohol dari buah anggur.",
    "story": "Jus anggur berasal dari wilayah budidaya anggur kuno dan menjadi alternatif non-alkohol dari buah anggur. Dalam katalog DrinkQ, Grape Juice ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Grape Juice memiliki konteks asal yang berkaitan dengan Mediterranean/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Grape Juice menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Hancurkan atau blender anggur, saring, lalu dinginkan."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/grape-juice.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Grape_juice",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Mediterranean/Global",
    "isPublished": true
  },
  {
    "id": "drink-pineapple-juice",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Pineapple Juice",
    "slug": "pineapple-juice",
    "origin": "Tropical Americas",
    "originRegion": "Americas",
    "shortDescription": "Jus nanas populer dari wilayah tropis penghasil nanas dan kemudian menyebar lewat industri minuman.",
    "story": "Jus nanas populer dari wilayah tropis penghasil nanas dan kemudian menyebar lewat industri minuman. Dalam katalog DrinkQ, Pineapple Juice ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Pineapple Juice memiliki konteks asal yang berkaitan dengan Tropical Americas. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Pineapple Juice menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender nanas dengan sedikit air, saring jika ingin halus, lalu sajikan dingin."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/pineapple-juice.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Pineapple_juice",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Tropical Americas",
    "isPublished": true
  },
  {
    "id": "drink-mango-lassi",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Mango Lassi",
    "slug": "mango-lassi",
    "origin": "India",
    "originRegion": "Asia",
    "shortDescription": "Mango lassi adalah turunan lassi India, minuman yogurt tradisional yang kemudian dipadukan dengan mangga.",
    "story": "Mango lassi adalah turunan lassi India, minuman yogurt tradisional yang kemudian dipadukan dengan mangga. Dalam katalog DrinkQ, Mango Lassi ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Mango Lassi memiliki konteks asal yang berkaitan dengan India. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Mango Lassi menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender yogurt, mangga matang, sedikit susu/air, dan gula sampai halus."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/mango-lassi.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Lassi",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "India",
    "isPublished": true
  },
  {
    "id": "drink-lassi",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Lassi",
    "slug": "lassi",
    "origin": "India",
    "originRegion": "Asia",
    "shortDescription": "Lassi adalah minuman yogurt klasik India yang sudah lama dikonsumsi sebagai penyejuk dan pendamping makanan.",
    "story": "Lassi adalah minuman yogurt klasik India yang sudah lama dikonsumsi sebagai penyejuk dan pendamping makanan. Dalam katalog DrinkQ, Lassi ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Lassi memiliki konteks asal yang berkaitan dengan India. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Lassi menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Kocok/blender yogurt, air, dan gula/garam.",
      "Bisa ditambah rempah atau buah."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/lassi.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Lassi",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "India",
    "isPublished": true
  },
  {
    "id": "drink-ayran",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Ayran",
    "slug": "ayran",
    "origin": "Turkey",
    "originRegion": "Asia",
    "shortDescription": "Ayran adalah minuman yogurt asin khas Anatolia yang populer di Turki dan kawasan sekitarnya.",
    "story": "Ayran adalah minuman yogurt asin khas Anatolia yang populer di Turki dan kawasan sekitarnya. Dalam katalog DrinkQ, Ayran ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Ayran memiliki konteks asal yang berkaitan dengan Turkey. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Ayran menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur yogurt, air dingin, dan sedikit garam lalu kocok hingga berbusa."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/ayran.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Ayran",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Turkey",
    "isPublished": true
  },
  {
    "id": "drink-kefir",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Kefir",
    "slug": "kefir",
    "origin": "Caucasus",
    "originRegion": "Americas",
    "shortDescription": "Kefir berasal dari kawasan Kaukasus dan dikenal sebagai minuman susu fermentasi.",
    "story": "Kefir berasal dari kawasan Kaukasus dan dikenal sebagai minuman susu fermentasi. Dalam katalog DrinkQ, Kefir ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Kefir memiliki konteks asal yang berkaitan dengan Caucasus. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Kefir menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Fermentasikan susu dengan kultur kefir sampai sedikit asam dan berkarbonasi ringan."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/kefir.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Kefir",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Caucasus",
    "isPublished": true
  },
  {
    "id": "drink-kombucha",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Kombucha",
    "slug": "kombucha",
    "origin": "China",
    "originRegion": "Asia",
    "shortDescription": "Kombucha dipercaya berakar di Asia Timur lalu menjadi populer global sebagai teh fermentasi.",
    "story": "Kombucha dipercaya berakar di Asia Timur lalu menjadi populer global sebagai teh fermentasi. Dalam katalog DrinkQ, Kombucha ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada tea-based, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Kombucha memiliki konteks asal yang berkaitan dengan China. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Kombucha menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Fermentasikan teh manis dengan SCOBY beberapa hari, lalu botolkan dan dinginkan."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/kombucha.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Kombucha",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "China",
    "isPublished": true
  },
  {
    "id": "drink-matcha-latte",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Matcha Latte",
    "slug": "matcha-latte",
    "origin": "Japan",
    "originRegion": "Asia",
    "shortDescription": "Matcha berasal dari tradisi teh bubuk Jepang, sedangkan latte adalah adaptasi modern yang populer global.",
    "story": "Matcha berasal dari tradisi teh bubuk Jepang, sedangkan latte adalah adaptasi modern yang populer global. Dalam katalog DrinkQ, Matcha Latte ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Tea-based, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Matcha Latte memiliki konteks asal yang berkaitan dengan Japan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Matcha Latte menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Kocok bubuk matcha dengan sedikit air panas, tambahkan susu panas/dingin dan pemanis."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Tea-based"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/matcha-latte.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Matcha",
    "relatedIngredientIds": [
      "ingredient-matcha",
      "ingredient-green-tea"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Japan",
    "isPublished": true
  },
  {
    "id": "drink-bubble-tea",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Bubble Tea",
    "slug": "bubble-tea",
    "origin": "Taiwan",
    "originRegion": "Asia",
    "shortDescription": "Bubble tea lahir di Taiwan pada akhir abad ke-20 lalu menjadi fenomena global.",
    "story": "Bubble tea lahir di Taiwan pada akhir abad ke-20 lalu menjadi fenomena global. Dalam katalog DrinkQ, Bubble Tea ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada tea-based, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Bubble Tea memiliki konteks asal yang berkaitan dengan Taiwan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Bubble Tea menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Seduh teh, tambahkan susu/sirup, masukkan boba yang sudah dimasak, lalu sajikan."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/bubble-tea.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Bubble_tea",
    "relatedIngredientIds": [
      "ingredient-black-tea",
      "ingredient-assam"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Taiwan",
    "isPublished": true
  },
  {
    "id": "drink-thai-iced-tea",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Thai Iced Tea",
    "slug": "thai-iced-tea",
    "origin": "Thailand",
    "originRegion": "Asia",
    "shortDescription": "Teh es Thailand berkembang dari budaya teh lokal dan pengaruh perdagangan teh modern.",
    "story": "Teh es Thailand berkembang dari budaya teh lokal dan pengaruh perdagangan teh modern. Dalam katalog DrinkQ, Thai Iced Tea ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada tea-based, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Thai Iced Tea memiliki konteks asal yang berkaitan dengan Thailand. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Thai Iced Tea menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Seduh teh hitam kuat, tambahkan susu kental/susu evaporasi dan gula, lalu sajikan dengan es."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/thai-iced-tea.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Thai_tea",
    "relatedIngredientIds": [
      "ingredient-black-tea",
      "ingredient-assam"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Thailand",
    "isPublished": true
  },
  {
    "id": "drink-masala-chai",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Masala Chai",
    "slug": "masala-chai",
    "origin": "India",
    "originRegion": "Asia",
    "shortDescription": "Masala chai adalah teh susu berbumbu yang melekat kuat pada budaya minum teh India.",
    "story": "Masala chai adalah teh susu berbumbu yang melekat kuat pada budaya minum teh India. Dalam katalog DrinkQ, Masala Chai ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada tea-based, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Masala Chai memiliki konteks asal yang berkaitan dengan India. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Masala Chai menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Rebus teh hitam dengan air, susu, gula, dan rempah seperti jahe, kapulaga, kayu manis."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/masala-chai.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Masala_chai",
    "relatedIngredientIds": [
      "ingredient-black-tea",
      "ingredient-assam"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "India",
    "isPublished": true
  },
  {
    "id": "drink-turkish-coffee",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Turkish Coffee",
    "slug": "turkish-coffee",
    "origin": "Turkey",
    "originRegion": "Asia",
    "shortDescription": "Kopi Turki terkenal sejak era Kesultanan Utsmaniyah dan menjadi gaya seduh khas kawasan tersebut.",
    "story": "Kopi Turki terkenal sejak era Kesultanan Utsmaniyah dan menjadi gaya seduh khas kawasan tersebut. Dalam katalog DrinkQ, Turkish Coffee ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Turkish Coffee memiliki konteks asal yang berkaitan dengan Turkey. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Turkish Coffee menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Masak kopi bubuk sangat halus dengan air dan gula dalam cezve sampai berbusa."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/turkish-coffee.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Turkish_coffee",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Turkey",
    "isPublished": true
  },
  {
    "id": "drink-espresso",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Espresso",
    "slug": "espresso",
    "origin": "Italy",
    "originRegion": "Europe",
    "shortDescription": "Espresso lahir di Italia bersama perkembangan mesin kopi bertekanan pada era modern.",
    "story": "Espresso lahir di Italia bersama perkembangan mesin kopi bertekanan pada era modern. Dalam katalog DrinkQ, Espresso ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Espresso memiliki konteks asal yang berkaitan dengan Italy. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Espresso menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Ekstrak kopi giling halus dengan mesin espresso selama sekitar 25–30 detik."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/espresso.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Espresso",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy",
    "isPublished": true
  },
  {
    "id": "drink-cappuccino",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Cappuccino",
    "slug": "cappuccino",
    "origin": "Italy",
    "originRegion": "Europe",
    "shortDescription": "Cappuccino adalah minuman kopi Italia yang berkembang dari budaya espresso dan susu berbusa.",
    "story": "Cappuccino adalah minuman kopi Italia yang berkembang dari budaya espresso dan susu berbusa. Dalam katalog DrinkQ, Cappuccino ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Tea-based, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Cappuccino memiliki konteks asal yang berkaitan dengan Italy. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Cappuccino menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Tarik satu shot espresso, tambahkan susu steamed dan foam seimbang."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Tea-based"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/cappuccino.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Cappuccino",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy",
    "isPublished": true
  },
  {
    "id": "drink-latte",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Latte",
    "slug": "latte",
    "origin": "Italy/Global",
    "originRegion": "Global",
    "shortDescription": "Caffè latte berasal dari tradisi kopi-susu Eropa dan dipopulerkan luas oleh kafe modern.",
    "story": "Caffè latte berasal dari tradisi kopi-susu Eropa dan dipopulerkan luas oleh kafe modern. Dalam katalog DrinkQ, Latte ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Tea-based, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Latte memiliki konteks asal yang berkaitan dengan Italy/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Latte menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Siapkan espresso lalu tambahkan lebih banyak susu steamed dengan sedikit foam."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Tea-based"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/latte.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Latte",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy/Global",
    "isPublished": true
  },
  {
    "id": "drink-americano",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Americano",
    "slug": "americano",
    "origin": "Italy/US",
    "originRegion": "Americas",
    "shortDescription": "Americano umumnya dikaitkan dengan penyesuaian espresso agar lebih mirip kopi seduh bagi tentara Amerika.",
    "story": "Americano umumnya dikaitkan dengan penyesuaian espresso agar lebih mirip kopi seduh bagi tentara Amerika. Dalam katalog DrinkQ, Americano ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Americano memiliki konteks asal yang berkaitan dengan Italy/US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Americano menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Campur espresso dengan air panas sesuai kekuatan yang diinginkan."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/americano.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Americano",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy/US",
    "isPublished": true
  },
  {
    "id": "drink-mocha",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Mocha",
    "slug": "mocha",
    "origin": "Italy/Global",
    "originRegion": "Global",
    "shortDescription": "Mocha modern menggabungkan kopi, susu, dan cokelat; namanya berkaitan dengan sejarah kopi Mocha.",
    "story": "Mocha modern menggabungkan kopi, susu, dan cokelat; namanya berkaitan dengan sejarah kopi Mocha. Dalam katalog DrinkQ, Mocha ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Tea-based, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Mocha memiliki konteks asal yang berkaitan dengan Italy/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Mocha menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Campur espresso dengan saus cokelat, tambahkan susu steamed, lalu beri topping opsional."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Tea-based"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/mocha.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Mocha",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy/Global",
    "isPublished": true
  },
  {
    "id": "drink-macchiato",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Macchiato",
    "slug": "macchiato",
    "origin": "Italy",
    "originRegion": "Europe",
    "shortDescription": "Macchiato berarti 'ditandai', merujuk pada espresso yang diberi sedikit busa atau susu.",
    "story": "Macchiato berarti 'ditandai', merujuk pada espresso yang diberi sedikit busa atau susu. Dalam katalog DrinkQ, Macchiato ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Macchiato memiliki konteks asal yang berkaitan dengan Italy. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Macchiato menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Buat espresso lalu tambahkan sedikit foam atau susu."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/macchiato.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Macchiato",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy",
    "isPublished": true
  },
  {
    "id": "drink-flat-white",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Flat White",
    "slug": "flat-white",
    "origin": "Australia/New Zealand",
    "originRegion": "Americas",
    "shortDescription": "Flat white berkembang di Australasia sebagai kopi susu dengan tekstur halus.",
    "story": "Flat white berkembang di Australasia sebagai kopi susu dengan tekstur halus. Dalam katalog DrinkQ, Flat White ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Flat White memiliki konteks asal yang berkaitan dengan Australia/New Zealand. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Flat White menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Campur double espresso dengan microfoam tipis."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/flat-white.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Flat_white",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Australia/New Zealand",
    "isPublished": true
  },
  {
    "id": "drink-affogato",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Affogato",
    "slug": "affogato",
    "origin": "Italy",
    "originRegion": "Europe",
    "shortDescription": "Affogato adalah hidangan penutup-minuman Italia berupa es krim yang 'ditenggelamkan' espresso.",
    "story": "Affogato adalah hidangan penutup-minuman Italia berupa es krim yang 'ditenggelamkan' espresso. Dalam katalog DrinkQ, Affogato ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Affogato memiliki konteks asal yang berkaitan dengan Italy. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Affogato menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Tuang espresso panas di atas satu scoop gelato/vanilla ice cream."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/affogato.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Affogato",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy",
    "isPublished": true
  },
  {
    "id": "drink-cold-brew",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Cold Brew",
    "slug": "cold-brew",
    "origin": "US/Global",
    "originRegion": "Global",
    "shortDescription": "Cold brew menjadi sangat populer pada era kopi modern karena rasa lebih lembut dan rendah pahit.",
    "story": "Cold brew menjadi sangat populer pada era kopi modern karena rasa lebih lembut dan rendah pahit. Dalam katalog DrinkQ, Cold Brew ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Cold Brew memiliki konteks asal yang berkaitan dengan US/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Cold Brew menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Rendam kopi kasar dalam air dingin 12–24 jam, saring, lalu sajikan dingin."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/cold-brew.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Cold_brew_coffee",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US/Global",
    "isPublished": true
  },
  {
    "id": "drink-iced-coffee",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Iced Coffee",
    "slug": "iced-coffee",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Kopi dingin memiliki banyak bentuk lokal dan populer luas di negara panas maupun jaringan kafe modern.",
    "story": "Kopi dingin memiliki banyak bentuk lokal dan populer luas di negara panas maupun jaringan kafe modern. Dalam katalog DrinkQ, Iced Coffee ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Iced Coffee memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Iced Coffee menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Seduh kopi, dinginkan, lalu sajikan dengan es dan pemanis/susu opsional."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/iced-coffee.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Iced_coffee",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-frappe",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Frappé",
    "slug": "frappe",
    "origin": "Greece",
    "originRegion": "Europe",
    "shortDescription": "Frappé kopi modern terkenal dari Yunani sebagai minuman kopi dingin berbusa.",
    "story": "Frappé kopi modern terkenal dari Yunani sebagai minuman kopi dingin berbusa. Dalam katalog DrinkQ, Frappé ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Frappé memiliki konteks asal yang berkaitan dengan Greece. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Frappé menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Kocok kopi instan, gula, dan sedikit air hingga berbusa, lalu tambahkan es dan air/susu."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/frappe.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Frapp%C3%A9",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Greece",
    "isPublished": true
  },
  {
    "id": "drink-irish-coffee",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Irish Coffee",
    "slug": "irish-coffee",
    "origin": "Ireland",
    "originRegion": "Europe",
    "shortDescription": "Irish coffee diciptakan sebagai campuran kopi panas, whiskey, gula, dan krim.",
    "story": "Irish coffee diciptakan sebagai campuran kopi panas, whiskey, gula, dan krim. Dalam katalog DrinkQ, Irish Coffee ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Irish Coffee memiliki konteks asal yang berkaitan dengan Ireland. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Irish Coffee menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Campur kopi panas, gula, dan whiskey.",
      "Beri lapisan krim di atas."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/irish-coffee.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Irish_coffee",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta",
      "ingredient-liberica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Ireland",
    "isPublished": true
  },
  {
    "id": "drink-sahlab",
    "type": "drink",
    "category": "traditional",
    "categoryLabel": "Hangat tradisional",
    "name": "Sahlab",
    "slug": "sahlab",
    "origin": "Middle East",
    "originRegion": "Asia",
    "shortDescription": "Sahlab adalah minuman hangat kental Timur Tengah yang sudah lama dikenal di kawasan Ottoman.",
    "story": "Sahlab adalah minuman hangat kental Timur Tengah yang sudah lama dikenal di kawasan Ottoman. Dalam katalog DrinkQ, Sahlab ditempatkan sebagai hangat tradisional yang tradisional dengan hubungan kuat pada kebiasaan lokal, bahan khas, dan budaya penyajian. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Sahlab memiliki konteks asal yang berkaitan dengan Middle East. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Sahlab menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan tradisional utama",
      "Air atau susu",
      "Rempah dan pemanis sesuai resep"
    ],
    "steps": [
      "Masak susu dengan bubuk sahlab/tepung pengental, gula, lalu taburi kayu manis."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/sahlab.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Sahlab",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Middle East",
    "isPublished": true
  },
  {
    "id": "drink-atole",
    "type": "drink",
    "category": "traditional",
    "categoryLabel": "Hangat tradisional",
    "name": "Atole",
    "slug": "atole",
    "origin": "Mexico",
    "originRegion": "Americas",
    "shortDescription": "Atole adalah minuman jagung hangat tradisional Meksiko dari warisan kuliner pra-Hispanik.",
    "story": "Atole adalah minuman jagung hangat tradisional Meksiko dari warisan kuliner pra-Hispanik. Dalam katalog DrinkQ, Atole ditempatkan sebagai hangat tradisional yang tradisional dengan hubungan kuat pada kebiasaan lokal, bahan khas, dan budaya penyajian. Catatan rasanya cenderung menonjol pada creamy, Spiced, dan Warm, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Atole memiliki konteks asal yang berkaitan dengan Mexico. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Atole menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan tradisional utama",
      "Air atau susu",
      "Rempah dan pemanis sesuai resep"
    ],
    "steps": [
      "Masak masa harina/tepung jagung dengan air atau susu, gula, dan kayu manis."
    ],
    "tasteNotes": [
      "Creamy",
      "Spiced",
      "Warm"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/atole.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Atole",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Mexico",
    "isPublished": true
  },
  {
    "id": "drink-horchata",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Horchata",
    "slug": "horchata",
    "origin": "Spain/Mexico",
    "originRegion": "Americas",
    "shortDescription": "Horchata punya beberapa tradisi; versi Spanyol berbasis tiger nut, versi Meksiko berbasis beras.",
    "story": "Horchata punya beberapa tradisi; versi Spanyol berbasis tiger nut, versi Meksiko berbasis beras. Dalam katalog DrinkQ, Horchata ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Horchata memiliki konteks asal yang berkaitan dengan Spain/Mexico. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Horchata menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Rendam beras/tiger nut, blender dengan air, saring, lalu tambahkan gula dan kayu manis."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/horchata.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Horchata",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Spain/Mexico",
    "isPublished": true
  },
  {
    "id": "drink-agua-fresca",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Agua Fresca",
    "slug": "agua-fresca",
    "origin": "Mexico",
    "originRegion": "Americas",
    "shortDescription": "Agua fresca adalah kelompok minuman buah ringan yang umum di Meksiko.",
    "story": "Agua fresca adalah kelompok minuman buah ringan yang umum di Meksiko. Dalam katalog DrinkQ, Agua Fresca ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Agua Fresca memiliki konteks asal yang berkaitan dengan Mexico. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Agua Fresca menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender buah dengan air, saring bila perlu, lalu maniskan dan sajikan dingin."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/agua-fresca.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Agua_Fresca",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Mexico",
    "isPublished": true
  },
  {
    "id": "drink-margarita",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Margarita",
    "slug": "margarita",
    "origin": "Mexico",
    "originRegion": "Americas",
    "shortDescription": "Margarita adalah koktail terkenal yang erat dengan tradisi bar Meksiko dan AS.",
    "story": "Margarita adalah koktail terkenal yang erat dengan tradisi bar Meksiko dan AS. Dalam katalog DrinkQ, Margarita ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada mixed, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Margarita memiliki konteks asal yang berkaitan dengan Mexico. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Margarita menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Kocok tequila, triple sec, dan air jeruk nipis dengan es.",
      "Sajikan di gelas berpinggir garam."
    ],
    "tasteNotes": [
      "Mixed",
      "Classic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/margarita.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Margarita",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Mexico",
    "isPublished": true
  },
  {
    "id": "drink-mojito",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Mojito",
    "slug": "mojito",
    "origin": "Cuba",
    "originRegion": "Americas",
    "shortDescription": "Mojito adalah highball Kuba yang populer global dengan mint dan lime.",
    "story": "Mojito adalah highball Kuba yang populer global dengan mint dan lime. Dalam katalog DrinkQ, Mojito ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, Refreshing, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Mojito memiliki konteks asal yang berkaitan dengan Cuba. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Mojito menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Muddle mint, gula, dan lime.",
      "Tambahkan rum, es, lalu top soda."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing",
      "Mixed"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/mojito.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Mojito",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Cuba",
    "isPublished": true
  },
  {
    "id": "drink-pina-colada",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Piña Colada",
    "slug": "pina-colada",
    "origin": "Puerto Rico",
    "originRegion": "Americas",
    "shortDescription": "Piña colada identik dengan Puerto Rico dan menjadi koktail tropis klasik.",
    "story": "Piña colada identik dengan Puerto Rico dan menjadi koktail tropis klasik. Dalam katalog DrinkQ, Piña Colada ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Piña Colada memiliki konteks asal yang berkaitan dengan Puerto Rico. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Piña Colada menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Blender rum, krim kelapa, jus nanas, dan es sampai lembut."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/pina-colada.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Pi%C3%B1a_colada",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Puerto Rico",
    "isPublished": true
  },
  {
    "id": "drink-daiquiri",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Daiquiri",
    "slug": "daiquiri",
    "origin": "Cuba",
    "originRegion": "Americas",
    "shortDescription": "Daiquiri berasal dari Kuba dan menjadi dasar banyak variasi koktail rum.",
    "story": "Daiquiri berasal dari Kuba dan menjadi dasar banyak variasi koktail rum. Dalam katalog DrinkQ, Daiquiri ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Daiquiri memiliki konteks asal yang berkaitan dengan Cuba. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Daiquiri menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Kocok rum, air jeruk nipis, dan gula dengan es."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/daiquiri.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Daiquiri",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Cuba",
    "isPublished": true
  },
  {
    "id": "drink-caipirinha",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Caipirinha",
    "slug": "caipirinha",
    "origin": "Brazil",
    "originRegion": "Americas",
    "shortDescription": "Caipirinha adalah koktail nasional Brasil berbasis cachaça, gula, dan lime.",
    "story": "Caipirinha adalah koktail nasional Brasil berbasis cachaça, gula, dan lime. Dalam katalog DrinkQ, Caipirinha ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Caipirinha memiliki konteks asal yang berkaitan dengan Brazil. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Caipirinha menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Muddle lime dan gula, tambahkan cachaça dan es."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/caipirinha.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Caipirinha",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Brazil",
    "isPublished": true
  },
  {
    "id": "drink-sangria",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Sangria",
    "slug": "sangria",
    "origin": "Spain",
    "originRegion": "Europe",
    "shortDescription": "Sangria adalah minuman anggur campur buah yang sangat identik dengan Spanyol.",
    "story": "Sangria adalah minuman anggur campur buah yang sangat identik dengan Spanyol. Dalam katalog DrinkQ, Sangria ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, Refreshing, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Sangria memiliki konteks asal yang berkaitan dengan Spain. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Sangria menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Campur wine, potongan buah, sedikit jus/soda/liqueur, lalu dinginkan."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing",
      "Mixed"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/sangria.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Sangria",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Spain",
    "isPublished": true
  },
  {
    "id": "drink-gin-and-tonic",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Gin and Tonic",
    "slug": "gin-and-tonic",
    "origin": "UK/India",
    "originRegion": "Europe",
    "shortDescription": "Gin and tonic populer dari masa kolonial Inggris ketika tonic dipakai dengan kina.",
    "story": "Gin and tonic populer dari masa kolonial Inggris ketika tonic dipakai dengan kina. Dalam katalog DrinkQ, Gin and Tonic ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Gin and Tonic memiliki konteks asal yang berkaitan dengan UK/India. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Gin and Tonic menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Isi gelas dengan es, gin, lalu tonic.",
      "Beri garnish citrus."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/gin-and-tonic.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Gin_and_tonic",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "UK/India",
    "isPublished": true
  },
  {
    "id": "drink-moscow-mule",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Moscow Mule",
    "slug": "moscow-mule",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Moscow mule dikenal dari budaya koktail Amerika abad ke-20 dan khas disajikan di mug tembaga.",
    "story": "Moscow mule dikenal dari budaya koktail Amerika abad ke-20 dan khas disajikan di mug tembaga. Dalam katalog DrinkQ, Moscow Mule ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada spiced, dan Warm, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Moscow Mule memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Moscow Mule menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Campur vodka, ginger beer, dan air jeruk nipis di atas es."
    ],
    "tasteNotes": [
      "Spiced",
      "Warm"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/moscow-mule.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Moscow_mule",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-whiskey-sour",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Whiskey Sour",
    "slug": "whiskey-sour",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Whiskey sour adalah koktail klasik keluarga sour yang sudah lama dikenal di dunia bar.",
    "story": "Whiskey sour adalah koktail klasik keluarga sour yang sudah lama dikenal di dunia bar. Dalam katalog DrinkQ, Whiskey Sour ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Whiskey Sour memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Whiskey Sour menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Kocok whiskey, lemon juice, gula, dan putih telur opsional dengan es."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Mixed"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/whiskey-sour.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Whiskey_Sour",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-old-fashioned",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Old Fashioned",
    "slug": "old-fashioned",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Old fashioned adalah salah satu koktail klasik tertua berbasis whiskey.",
    "story": "Old fashioned adalah salah satu koktail klasik tertua berbasis whiskey. Dalam katalog DrinkQ, Old Fashioned ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Old Fashioned memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Old Fashioned menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Aduk whiskey dengan gula/sirup dan bitters, lalu sajikan dengan es."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/old-fashioned.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Old_fashioned_(cocktail)",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-negroni",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Negroni",
    "slug": "negroni",
    "origin": "Italy",
    "originRegion": "Europe",
    "shortDescription": "Negroni berasal dari Italia dan terkenal dengan rasa pahit-manis seimbang.",
    "story": "Negroni berasal dari Italia dan terkenal dengan rasa pahit-manis seimbang. Dalam katalog DrinkQ, Negroni ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada mixed, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Negroni memiliki konteks asal yang berkaitan dengan Italy. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Negroni menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Aduk gin, Campari, dan sweet vermouth dengan es."
    ],
    "tasteNotes": [
      "Mixed",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/negroni.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Negroni",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy",
    "isPublished": true
  },
  {
    "id": "drink-martini",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Martini",
    "slug": "martini",
    "origin": "US/Europe",
    "originRegion": "Americas",
    "shortDescription": "Martini menjadi ikon budaya koktail modern dengan banyak variasi gin atau vodka.",
    "story": "Martini menjadi ikon budaya koktail modern dengan banyak variasi gin atau vodka. Dalam katalog DrinkQ, Martini ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada mixed, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Martini memiliki konteks asal yang berkaitan dengan US/Europe. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Martini menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Aduk/kocok gin atau vodka dengan vermouth, lalu saring ke gelas dingin."
    ],
    "tasteNotes": [
      "Mixed",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/martini.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Martini",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US/Europe",
    "isPublished": true
  },
  {
    "id": "drink-bloody-mary",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Bloody Mary",
    "slug": "bloody-mary",
    "origin": "US/Europe",
    "originRegion": "Americas",
    "shortDescription": "Bloody Mary dikenal sebagai koktail berbasis tomat yang gurih dan berbumbu.",
    "story": "Bloody Mary dikenal sebagai koktail berbasis tomat yang gurih dan berbumbu. Dalam katalog DrinkQ, Bloody Mary ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada fruity, dan Fresh, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Bloody Mary memiliki konteks asal yang berkaitan dengan US/Europe. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Bloody Mary menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur vodka, jus tomat, lemon, saus Inggris, garam, lada, dan es."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/bloody-mary.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Bloody_Mary_(cocktail)",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US/Europe",
    "isPublished": true
  },
  {
    "id": "drink-mimosa",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Mimosa",
    "slug": "mimosa",
    "origin": "France/US",
    "originRegion": "Americas",
    "shortDescription": "Mimosa menjadi minuman brunch klasik dari perpaduan sparkling wine dan jus jeruk.",
    "story": "Mimosa menjadi minuman brunch klasik dari perpaduan sparkling wine dan jus jeruk. Dalam katalog DrinkQ, Mimosa ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, Refreshing, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Mimosa memiliki konteks asal yang berkaitan dengan France/US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Mimosa menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Tuang sparkling wine dan jus jeruk dingin ke gelas flute."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing",
      "Mixed"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/mimosa.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Mimosa",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "France/US",
    "isPublished": true
  },
  {
    "id": "drink-bellini",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Bellini",
    "slug": "bellini",
    "origin": "Italy",
    "originRegion": "Europe",
    "shortDescription": "Bellini berasal dari Venesia, Italia, dan terkenal dengan perpaduan peach dan prosecco.",
    "story": "Bellini berasal dari Venesia, Italia, dan terkenal dengan perpaduan peach dan prosecco. Dalam katalog DrinkQ, Bellini ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Bellini memiliki konteks asal yang berkaitan dengan Italy. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Bellini menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Campur pure peach putih dengan prosecco dingin."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/bellini.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Bellini",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy",
    "isPublished": true
  },
  {
    "id": "drink-milkshake",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Milkshake",
    "slug": "milkshake",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Milkshake berkembang di Amerika menjadi minuman pencuci mulut yang populer.",
    "story": "Milkshake berkembang di Amerika menjadi minuman pencuci mulut yang populer. Dalam katalog DrinkQ, Milkshake ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Milkshake memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Milkshake menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender es krim, susu, dan perisa sampai kental."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/milkshake.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Milkshake",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-smoothie",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Smoothie",
    "slug": "smoothie",
    "origin": "US/Global",
    "originRegion": "Global",
    "shortDescription": "Smoothie populer luas pada era modern kesehatan dan budaya blender rumah.",
    "story": "Smoothie populer luas pada era modern kesehatan dan budaya blender rumah. Dalam katalog DrinkQ, Smoothie ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Smoothie memiliki konteks asal yang berkaitan dengan US/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Smoothie menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender buah, cairan, dan yogurt/es sesuai selera."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/smoothie.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Smoothie",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US/Global",
    "isPublished": true
  },
  {
    "id": "drink-banana-shake",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Banana Shake",
    "slug": "banana-shake",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Banana shake adalah minuman buah sederhana yang populer di banyak negara.",
    "story": "Banana shake adalah minuman buah sederhana yang populer di banyak negara. Dalam katalog DrinkQ, Banana Shake ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Banana Shake memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Banana Shake menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender pisang, susu/air, es, dan gula/madu."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/banana-shake.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Banana_Shake",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-strawberry-shake",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Strawberry Shake",
    "slug": "strawberry-shake",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Shake stroberi menjadi favorit kafe dan rumah karena rasa manis-asamnya.",
    "story": "Shake stroberi menjadi favorit kafe dan rumah karena rasa manis-asamnya. Dalam katalog DrinkQ, Strawberry Shake ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Strawberry Shake memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Strawberry Shake menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender stroberi, susu, es krim atau yogurt, dan es."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/strawberry-shake.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Strawberry_Shake",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-avocado-juice",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Avocado Juice",
    "slug": "avocado-juice",
    "origin": "Southeast Asia",
    "originRegion": "Asia",
    "shortDescription": "Jus alpukat populer di Asia Tenggara sebagai minuman kaya tekstur.",
    "story": "Jus alpukat populer di Asia Tenggara sebagai minuman kaya tekstur. Dalam katalog DrinkQ, Avocado Juice ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Avocado Juice memiliki konteks asal yang berkaitan dengan Southeast Asia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Avocado Juice menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Blender alpukat dengan susu, air, gula, dan es."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/avocado-juice.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Avocado_Juice",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Southeast Asia",
    "isPublished": true
  },
  {
    "id": "drink-sugarcane-juice",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Sugarcane Juice",
    "slug": "sugarcane-juice",
    "origin": "South Asia/SE Asia",
    "originRegion": "Asia",
    "shortDescription": "Jus tebu telah lama dijual sebagai minuman segar di wilayah tropis penghasil tebu.",
    "story": "Jus tebu telah lama dijual sebagai minuman segar di wilayah tropis penghasil tebu. Dalam katalog DrinkQ, Sugarcane Juice ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Sugarcane Juice memiliki konteks asal yang berkaitan dengan South Asia/SE Asia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Sugarcane Juice menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Peras batang tebu dengan mesin, tambahkan es dan citrus opsional."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/sugarcane-juice.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Sugarcane_Juice",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "South Asia/SE Asia",
    "isPublished": true
  },
  {
    "id": "drink-coconut-water",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Coconut Water",
    "slug": "coconut-water",
    "origin": "Tropics",
    "originRegion": "Tropical",
    "shortDescription": "Air kelapa dikonsumsi luas di daerah tropis sebagai minuman alami penyegar.",
    "story": "Air kelapa dikonsumsi luas di daerah tropis sebagai minuman alami penyegar. Dalam katalog DrinkQ, Coconut Water ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada fruity, dan Fresh, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Coconut Water memiliki konteks asal yang berkaitan dengan Tropics. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Coconut Water menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Air kelapa muda",
      "Es opsional"
    ],
    "steps": [
      "Sajikan langsung dari kelapa muda atau dinginkan terlebih dahulu."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/coconut-water.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Coconut_water",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Tropics",
    "isPublished": true
  },
  {
    "id": "drink-soda",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Soda",
    "slug": "soda",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Minuman bersoda berkembang dari air berkarbonasi dan industri soft drink modern.",
    "story": "Minuman bersoda berkembang dari air berkarbonasi dan industri soft drink modern. Dalam katalog DrinkQ, Soda ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Soda memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Soda menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur sirup/perisa dengan air berkarbonasi atau sajikan produk siap minum."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/soda.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Soft_drink",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-cola",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Cola",
    "slug": "cola",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Cola muncul pada akhir abad ke-19 dan menjadi salah satu kategori soft drink terbesar di dunia.",
    "story": "Cola muncul pada akhir abad ke-19 dan menjadi salah satu kategori soft drink terbesar di dunia. Dalam katalog DrinkQ, Cola ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Cola memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Cola menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Sajikan dingin langsung dari botol/kaleng atau dengan es."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/cola.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Cola",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-root-beer",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Root Beer",
    "slug": "root-beer",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Root beer berasal dari tradisi minuman herbal Amerika Utara lalu menjadi soda komersial.",
    "story": "Root beer berasal dari tradisi minuman herbal Amerika Utara lalu menjadi soda komersial. Dalam katalog DrinkQ, Root Beer ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Root Beer memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Root Beer menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Sajikan dingin.",
      "Versi rumahan dibuat dari ekstrak root beer, gula, dan karbonasi."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/root-beer.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Root_beer",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-ginger-ale",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Ginger Ale",
    "slug": "ginger-ale",
    "origin": "US/Canada",
    "originRegion": "Americas",
    "shortDescription": "Ginger ale menjadi soda jahe populer sebagai minuman segar dan mixer.",
    "story": "Ginger ale menjadi soda jahe populer sebagai minuman segar dan mixer. Dalam katalog DrinkQ, Ginger Ale ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada spiced, dan Warm, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Ginger Ale memiliki konteks asal yang berkaitan dengan US/Canada. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Ginger Ale menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Jahe",
      "Air panas",
      "Gula merah/madu",
      "Rempah opsional"
    ],
    "steps": [
      "Campur sirup jahe dengan air berkarbonasi atau gunakan versi kemasan."
    ],
    "tasteNotes": [
      "Spiced",
      "Warm"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/ginger-ale.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Ginger_ale",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US/Canada",
    "isPublished": true
  },
  {
    "id": "drink-tonic-water",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Tonic Water",
    "slug": "tonic-water",
    "origin": "UK/India",
    "originRegion": "Europe",
    "shortDescription": "Tonic berkembang dari minuman kina medis menjadi mixer populer.",
    "story": "Tonic berkembang dari minuman kina medis menjadi mixer populer. Dalam katalog DrinkQ, Tonic Water ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Tonic Water memiliki konteks asal yang berkaitan dengan UK/India. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Tonic Water menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Sajikan dingin.",
      "Biasanya dipakai langsung sebagai mixer."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/tonic-water.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Tonic_water",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "UK/India",
    "isPublished": true
  },
  {
    "id": "drink-energy-drink",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Energy Drink",
    "slug": "energy-drink",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Energy drink muncul pada era modern sebagai minuman fungsional berkafein.",
    "story": "Energy drink muncul pada era modern sebagai minuman fungsional berkafein. Dalam katalog DrinkQ, Energy Drink ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Energy Drink memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Energy Drink menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Disajikan dingin langsung dari kemasan."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/energy-drink.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Energy_drink",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-sports-drink",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Sports Drink",
    "slug": "sports-drink",
    "origin": "US/Global",
    "originRegion": "Global",
    "shortDescription": "Sports drink berkembang untuk membantu hidrasi dan elektrolit saat aktivitas.",
    "story": "Sports drink berkembang untuk membantu hidrasi dan elektrolit saat aktivitas. Dalam katalog DrinkQ, Sports Drink ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Sports Drink memiliki konteks asal yang berkaitan dengan US/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Sports Drink menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur bubuk/sirup elektrolit dengan air atau sajikan versi botolan."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/sports-drink.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Sports_drink",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US/Global",
    "isPublished": true
  },
  {
    "id": "drink-yakult-probiotic-drink",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Yakult / Probiotic Drink",
    "slug": "yakult-probiotic-drink",
    "origin": "Japan",
    "originRegion": "Asia",
    "shortDescription": "Minuman probiotik modern populer lewat produk susu fermentasi seperti Yakult dari Jepang.",
    "story": "Minuman probiotik modern populer lewat produk susu fermentasi seperti Yakult dari Jepang. Dalam katalog DrinkQ, Yakult / Probiotic Drink ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Yakult / Probiotic Drink memiliki konteks asal yang berkaitan dengan Japan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Yakult / Probiotic Drink menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Diminum dingin langsung dari botol kecil."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/yakult-probiotic-drink.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Yakult",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Japan",
    "isPublished": true
  },
  {
    "id": "drink-ramune",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Ramune",
    "slug": "ramune",
    "origin": "Japan",
    "originRegion": "Asia",
    "shortDescription": "Ramune adalah soda Jepang klasik yang terkenal dengan botol Codd berpeluru kaca.",
    "story": "Ramune adalah soda Jepang klasik yang terkenal dengan botol Codd berpeluru kaca. Dalam katalog DrinkQ, Ramune ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Ramune memiliki konteks asal yang berkaitan dengan Japan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Ramune menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Sajikan dingin setelah membuka kunci kelereng botol."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/ramune.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Ramune",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Japan",
    "isPublished": true
  },
  {
    "id": "drink-calpis",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Calpis",
    "slug": "calpis",
    "origin": "Japan",
    "originRegion": "Asia",
    "shortDescription": "Calpis adalah minuman konsentrat susu fermentasi asal Jepang yang populer sejak awal abad ke-20.",
    "story": "Calpis adalah minuman konsentrat susu fermentasi asal Jepang yang populer sejak awal abad ke-20. Dalam katalog DrinkQ, Calpis ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada tea-based, Aromatic, dan Sparkling, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Calpis memiliki konteks asal yang berkaitan dengan Japan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Calpis menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Campur konsentrat dengan air dingin atau soda."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic",
      "Sparkling"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/calpis.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Calpis",
    "relatedIngredientIds": [
      "ingredient-green-tea",
      "ingredient-black-tea",
      "ingredient-oolong-tea"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Japan",
    "isPublished": true
  },
  {
    "id": "drink-boba-brown-sugar-milk",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Boba Brown Sugar Milk",
    "slug": "boba-brown-sugar-milk",
    "origin": "Taiwan",
    "originRegion": "Asia",
    "shortDescription": "Varian ini berkembang dari tren bubble tea modern Taiwan.",
    "story": "Varian ini berkembang dari tren bubble tea modern Taiwan. Dalam katalog DrinkQ, Boba Brown Sugar Milk ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Boba Brown Sugar Milk memiliki konteks asal yang berkaitan dengan Taiwan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Boba Brown Sugar Milk menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Masak boba, lapisi gelas dengan sirup gula aren, tambahkan susu dan es."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/boba-brown-sugar-milk.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Bubble_tea",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Taiwan",
    "isPublished": true
  },
  {
    "id": "drink-vietnamese-iced-coffee",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Vietnamese Iced Coffee",
    "slug": "vietnamese-iced-coffee",
    "origin": "Vietnam",
    "originRegion": "Asia",
    "shortDescription": "Kopi susu Vietnam terkenal karena penggunaan robusta dan susu kental manis.",
    "story": "Kopi susu Vietnam terkenal karena penggunaan robusta dan susu kental manis. Dalam katalog DrinkQ, Vietnamese Iced Coffee ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Vietnamese Iced Coffee memiliki konteks asal yang berkaitan dengan Vietnam. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Vietnamese Iced Coffee menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Seduh kopi dengan phin, campur susu kental manis, lalu sajikan dengan es."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/vietnamese-iced-coffee.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Vietnamese_iced_coffee",
    "relatedIngredientIds": [
      "ingredient-robusta",
      "ingredient-arabica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Vietnam",
    "isPublished": true
  },
  {
    "id": "drink-kopi-tubruk",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Kopi Tubruk",
    "slug": "kopi-tubruk",
    "origin": "Indonesia",
    "originRegion": "Asia",
    "shortDescription": "Kopi tubruk adalah gaya seduh sederhana khas Indonesia yang sangat populer.",
    "story": "Kopi tubruk adalah gaya seduh sederhana khas Indonesia yang sangat populer. Dalam katalog DrinkQ, Kopi Tubruk ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Kopi Tubruk memiliki konteks asal yang berkaitan dengan Indonesia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Kopi Tubruk menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Seduh kopi bubuk langsung dengan air panas dan gula opsional."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/kopi-tubruk.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Kopi_tubruk",
    "relatedIngredientIds": [
      "ingredient-robusta",
      "ingredient-arabica"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Indonesia",
    "isPublished": true
  },
  {
    "id": "drink-es-cendol-dawet",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Es Cendol / Dawet",
    "slug": "es-cendol-dawet",
    "origin": "Indonesia",
    "originRegion": "Asia",
    "shortDescription": "Cendol adalah minuman tradisional Nusantara dengan santan dan gula aren.",
    "story": "Cendol adalah minuman tradisional Nusantara dengan santan dan gula aren. Dalam katalog DrinkQ, Es Cendol / Dawet ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Es Cendol / Dawet memiliki konteks asal yang berkaitan dengan Indonesia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Es Cendol / Dawet menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Isi gelas dengan cendol, es, santan, dan larutan gula aren."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/es-cendol-dawet.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Cendol",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Indonesia",
    "isPublished": true
  },
  {
    "id": "drink-bajigur",
    "type": "drink",
    "category": "traditional",
    "categoryLabel": "Hangat tradisional",
    "name": "Bajigur",
    "slug": "bajigur",
    "origin": "Indonesia",
    "originRegion": "Asia",
    "shortDescription": "Bajigur adalah minuman hangat Sunda berbasis santan dan gula aren.",
    "story": "Bajigur adalah minuman hangat Sunda berbasis santan dan gula aren. Dalam katalog DrinkQ, Bajigur ditempatkan sebagai hangat tradisional yang tradisional dengan hubungan kuat pada kebiasaan lokal, bahan khas, dan budaya penyajian. Catatan rasanya cenderung menonjol pada spiced, dan Warm, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Bajigur memiliki konteks asal yang berkaitan dengan Indonesia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Bajigur menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan tradisional utama",
      "Air atau susu",
      "Rempah dan pemanis sesuai resep"
    ],
    "steps": [
      "Rebus santan, gula aren, jahe, dan sedikit garam hingga harum."
    ],
    "tasteNotes": [
      "Spiced",
      "Warm"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/bajigur.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Bajigur",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Indonesia",
    "isPublished": true
  },
  {
    "id": "drink-bandrek",
    "type": "drink",
    "category": "traditional",
    "categoryLabel": "Hangat tradisional",
    "name": "Bandrek",
    "slug": "bandrek",
    "origin": "Indonesia",
    "originRegion": "Asia",
    "shortDescription": "Bandrek adalah minuman jahe hangat tradisional Sunda.",
    "story": "Bandrek adalah minuman jahe hangat tradisional Sunda. Dalam katalog DrinkQ, Bandrek ditempatkan sebagai hangat tradisional yang tradisional dengan hubungan kuat pada kebiasaan lokal, bahan khas, dan budaya penyajian. Catatan rasanya cenderung menonjol pada creamy, Spiced, dan Warm, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Bandrek memiliki konteks asal yang berkaitan dengan Indonesia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Bandrek menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan tradisional utama",
      "Air atau susu",
      "Rempah dan pemanis sesuai resep"
    ],
    "steps": [
      "Rebus jahe, gula, dan rempah.",
      "Tambahkan susu opsional."
    ],
    "tasteNotes": [
      "Creamy",
      "Spiced",
      "Warm"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/bandrek.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Bandrek",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Indonesia",
    "isPublished": true
  },
  {
    "id": "drink-jamu-kunyit-asam",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Jamu Kunyit Asam",
    "slug": "jamu-kunyit-asam",
    "origin": "Indonesia",
    "originRegion": "Asia",
    "shortDescription": "Kunyit asam merupakan jamu populer Indonesia yang dikenal sebagai minuman herbal.",
    "story": "Kunyit asam merupakan jamu populer Indonesia yang dikenal sebagai minuman herbal. Dalam katalog DrinkQ, Jamu Kunyit Asam ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Jamu Kunyit Asam memiliki konteks asal yang berkaitan dengan Indonesia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Jamu Kunyit Asam menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Rebus kunyit dan asam jawa dengan gula, saring, lalu sajikan hangat/dingin."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/jamu-kunyit-asam.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Jamu",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Indonesia",
    "isPublished": true
  },
  {
    "id": "drink-wedang-jahe",
    "type": "drink",
    "category": "traditional",
    "categoryLabel": "Hangat tradisional",
    "name": "Wedang Jahe",
    "slug": "wedang-jahe",
    "origin": "Indonesia",
    "originRegion": "Asia",
    "shortDescription": "Wedang jahe adalah minuman jahe tradisional Jawa untuk menghangatkan tubuh.",
    "story": "Wedang jahe adalah minuman jahe tradisional Jawa untuk menghangatkan tubuh. Dalam katalog DrinkQ, Wedang Jahe ditempatkan sebagai hangat tradisional yang tradisional dengan hubungan kuat pada kebiasaan lokal, bahan khas, dan budaya penyajian. Catatan rasanya cenderung menonjol pada spiced, dan Warm, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Wedang Jahe memiliki konteks asal yang berkaitan dengan Indonesia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Wedang Jahe menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Jahe",
      "Air panas",
      "Gula merah/madu",
      "Rempah opsional"
    ],
    "steps": [
      "Rebus jahe dengan air dan gula batu.",
      "Tambahkan serai/kayu manis opsional."
    ],
    "tasteNotes": [
      "Spiced",
      "Warm"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/wedang-jahe.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Wedang_jahe",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Indonesia",
    "isPublished": true
  },
  {
    "id": "drink-es-teh-manis",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Es Teh Manis",
    "slug": "es-teh-manis",
    "origin": "Indonesia",
    "originRegion": "Asia",
    "shortDescription": "Es teh manis menjadi minuman harian yang sangat populer di Indonesia modern.",
    "story": "Es teh manis menjadi minuman harian yang sangat populer di Indonesia modern. Dalam katalog DrinkQ, Es Teh Manis ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada tea-based, dan Aromatic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Es Teh Manis memiliki konteks asal yang berkaitan dengan Indonesia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Es Teh Manis menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Seduh teh, tambahkan gula, dinginkan, lalu sajikan dengan es."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/es-teh-manis.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Iced_tea",
    "relatedIngredientIds": [
      "ingredient-green-tea",
      "ingredient-black-tea",
      "ingredient-oolong-tea"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Indonesia",
    "isPublished": true
  },
  {
    "id": "drink-sarsaparilla",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Sarsaparilla",
    "slug": "sarsaparilla",
    "origin": "Americas",
    "originRegion": "Americas",
    "shortDescription": "Sarsaparilla berasal dari penggunaan akar tanaman sebagai minuman herbal dan soda awal.",
    "story": "Sarsaparilla berasal dari penggunaan akar tanaman sebagai minuman herbal dan soda awal. Dalam katalog DrinkQ, Sarsaparilla ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Sarsaparilla memiliki konteks asal yang berkaitan dengan Americas. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Sarsaparilla menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Rebus ekstrak sarsaparilla atau sajikan versi soda dingin."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/sarsaparilla.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Sarsaparilla",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Americas",
    "isPublished": true
  },
  {
    "id": "drink-mate",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Mate",
    "slug": "mate",
    "origin": "South America",
    "originRegion": "Americas",
    "shortDescription": "Yerba mate adalah minuman tradisional Amerika Selatan dengan akar budaya kuat.",
    "story": "Yerba mate adalah minuman tradisional Amerika Selatan dengan akar budaya kuat. Dalam katalog DrinkQ, Mate ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Mate memiliki konteks asal yang berkaitan dengan South America. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Mate menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Seduh daun yerba mate dalam air panas di mate cup atau french press."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/mate.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Mate_(drink)",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "South America",
    "isPublished": true
  },
  {
    "id": "drink-terere",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Tereré",
    "slug": "terere",
    "origin": "Paraguay",
    "originRegion": "Americas",
    "shortDescription": "Tereré adalah versi dingin dari mate yang sangat populer di Paraguay.",
    "story": "Tereré adalah versi dingin dari mate yang sangat populer di Paraguay. Dalam katalog DrinkQ, Tereré ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Tereré memiliki konteks asal yang berkaitan dengan Paraguay. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Tereré menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Seduh/rendam yerba mate dengan air dingin atau jus dan es."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/terere.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Terer%C3%A9",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Paraguay",
    "isPublished": true
  },
  {
    "id": "drink-cider-non-alcoholic",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Cider (Non-alcoholic)",
    "slug": "cider-non-alcoholic",
    "origin": "Europe/North America",
    "originRegion": "Americas",
    "shortDescription": "Cider apel non-alkohol berasal dari tradisi pengolahan apel di wilayah beriklim sedang.",
    "story": "Cider apel non-alkohol berasal dari tradisi pengolahan apel di wilayah beriklim sedang. Dalam katalog DrinkQ, Cider (Non-alcoholic) ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Cider (Non-alcoholic) memiliki konteks asal yang berkaitan dengan Europe/North America. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Cider (Non-alcoholic) menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Panaskan atau dinginkan sari apel berbumbu sesuai selera."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/cider-non-alcoholic.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Apple_cider",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Europe/North America",
    "isPublished": true
  },
  {
    "id": "drink-mulled-wine",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Mulled Wine",
    "slug": "mulled-wine",
    "origin": "Europe",
    "originRegion": "Europe",
    "shortDescription": "Mulled wine telah lama hadir di Eropa sebagai minuman anggur hangat berbumbu.",
    "story": "Mulled wine telah lama hadir di Eropa sebagai minuman anggur hangat berbumbu. Dalam katalog DrinkQ, Mulled Wine ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada spiced, Warm, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Mulled Wine memiliki konteks asal yang berkaitan dengan Europe. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Mulled Wine menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Panaskan wine dengan citrus, gula, dan rempah tanpa mendidihkan."
    ],
    "tasteNotes": [
      "Spiced",
      "Warm",
      "Mixed"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/mulled-wine.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Mulled_wine",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Europe",
    "isPublished": true
  },
  {
    "id": "drink-gluhwein",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Glühwein",
    "slug": "gluhwein",
    "origin": "Germany",
    "originRegion": "Europe",
    "shortDescription": "Glühwein adalah versi Jerman dari anggur hangat berbumbu yang populer saat musim dingin.",
    "story": "Glühwein adalah versi Jerman dari anggur hangat berbumbu yang populer saat musim dingin. Dalam katalog DrinkQ, Glühwein ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada mixed, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Glühwein memiliki konteks asal yang berkaitan dengan Germany. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Glühwein menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Panaskan red wine dengan gula, jeruk, cengkih, dan kayu manis."
    ],
    "tasteNotes": [
      "Mixed",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/gluhwein.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Gl%C3%BChwein",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Germany",
    "isPublished": true
  },
  {
    "id": "drink-punch",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Punch",
    "slug": "punch",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Punch punya sejarah panjang dari India ke Inggris lalu menyebar ke dunia dalam banyak variasi.",
    "story": "Punch punya sejarah panjang dari India ke Inggris lalu menyebar ke dunia dalam banyak variasi. Dalam katalog DrinkQ, Punch ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada tea-based, Aromatic, dan Sparkling, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Punch memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Punch menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur basis teh/jus/alkohol dengan gula, citrus, dan air/soda."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic",
      "Sparkling"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/punch.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Punch",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-sherbet-drink",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Sherbet Drink",
    "slug": "sherbet-drink",
    "origin": "Middle East/South Asia",
    "originRegion": "Asia",
    "shortDescription": "Sherbet atau sharbat adalah minuman manis berbasis bunga/buah yang sangat tua di dunia Islam.",
    "story": "Sherbet atau sharbat adalah minuman manis berbasis bunga/buah yang sangat tua di dunia Islam. Dalam katalog DrinkQ, Sherbet Drink ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Sherbet Drink memiliki konteks asal yang berkaitan dengan Middle East/South Asia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Sherbet Drink menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur sirup buah/bunga dengan air dingin dan es."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/sherbet-drink.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Sharbat",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Middle East/South Asia",
    "isPublished": true
  },
  {
    "id": "drink-rose-milk",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Rose Milk",
    "slug": "rose-milk",
    "origin": "India",
    "originRegion": "Asia",
    "shortDescription": "Rose milk populer di India dan Asia Selatan sebagai minuman susu beraroma mawar.",
    "story": "Rose milk populer di India dan Asia Selatan sebagai minuman susu beraroma mawar. Dalam katalog DrinkQ, Rose Milk ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Rose Milk memiliki konteks asal yang berkaitan dengan India. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Rose Milk menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Campur susu dingin dengan sirup mawar dan es."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/rose-milk.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Rose_milk",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "India",
    "isPublished": true
  },
  {
    "id": "drink-falooda",
    "type": "drink",
    "category": "juice",
    "categoryLabel": "Buah / dairy / dessert",
    "name": "Falooda",
    "slug": "falooda",
    "origin": "South Asia",
    "originRegion": "Asia",
    "shortDescription": "Falooda berkembang dari tradisi Persia-Asia Selatan menjadi minuman pencuci mulut.",
    "story": "Falooda berkembang dari tradisi Persia-Asia Selatan menjadi minuman pencuci mulut. Dalam katalog DrinkQ, Falooda ditempatkan sebagai buah / dairy / dessert yang berbasis buah dengan rasa segar, ringan, dan mudah diterima banyak orang. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Falooda memiliki konteks asal yang berkaitan dengan South Asia. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Falooda menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Buah atau bahan utama",
      "Air/susu/yogurt sesuai resep",
      "Es dan pemanis opsional"
    ],
    "steps": [
      "Susun vermicelli, basil seed, sirup mawar, susu, es krim, dan es."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/falooda.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Falooda",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "South Asia",
    "isPublished": true
  },
  {
    "id": "drink-salep",
    "type": "drink",
    "category": "traditional",
    "categoryLabel": "Hangat tradisional",
    "name": "Salep",
    "slug": "salep",
    "origin": "Turkey/Middle East",
    "originRegion": "Asia",
    "shortDescription": "Salep adalah minuman hangat khas Turki dari bubuk anggrek/sahlab.",
    "story": "Salep adalah minuman hangat khas Turki dari bubuk anggrek/sahlab. Dalam katalog DrinkQ, Salep ditempatkan sebagai hangat tradisional yang tradisional dengan hubungan kuat pada kebiasaan lokal, bahan khas, dan budaya penyajian. Catatan rasanya cenderung menonjol pada creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Salep memiliki konteks asal yang berkaitan dengan Turkey/Middle East. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Salep menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan tradisional utama",
      "Air atau susu",
      "Rempah dan pemanis sesuai resep"
    ],
    "steps": [
      "Masak susu dengan salep dan gula hingga kental."
    ],
    "tasteNotes": [
      "Creamy"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/salep.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Salep",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Turkey/Middle East",
    "isPublished": true
  },
  {
    "id": "drink-kvass",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Kvass",
    "slug": "kvass",
    "origin": "Eastern Europe",
    "originRegion": "Europe",
    "shortDescription": "Kvass adalah minuman fermentasi ringan tradisional Eropa Timur berbasis roti.",
    "story": "Kvass adalah minuman fermentasi ringan tradisional Eropa Timur berbasis roti. Dalam katalog DrinkQ, Kvass ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Kvass memiliki konteks asal yang berkaitan dengan Eastern Europe. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Kvass menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Fermentasikan roti/gula/air dengan kultur ragi secara ringan."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/kvass.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Kvass",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Eastern Europe",
    "isPublished": true
  },
  {
    "id": "drink-amazake",
    "type": "drink",
    "category": "traditional",
    "categoryLabel": "Hangat tradisional",
    "name": "Amazake",
    "slug": "amazake",
    "origin": "Japan",
    "originRegion": "Asia",
    "shortDescription": "Amazake adalah minuman manis fermentasi Jepang yang dibuat dari beras dan koji.",
    "story": "Amazake adalah minuman manis fermentasi Jepang yang dibuat dari beras dan koji. Dalam katalog DrinkQ, Amazake ditempatkan sebagai hangat tradisional yang tradisional dengan hubungan kuat pada kebiasaan lokal, bahan khas, dan budaya penyajian. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Amazake memiliki konteks asal yang berkaitan dengan Japan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Amazake menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan tradisional utama",
      "Air atau susu",
      "Rempah dan pemanis sesuai resep"
    ],
    "steps": [
      "Masak atau fermentasikan nasi/koji hingga manis, lalu encerkan."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/amazake.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Amazake",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Japan",
    "isPublished": true
  },
  {
    "id": "drink-sake",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Sake",
    "slug": "sake",
    "origin": "Japan",
    "originRegion": "Asia",
    "shortDescription": "Sake adalah minuman beras fermentasi Jepang dengan sejarah panjang dalam budaya setempat.",
    "story": "Sake adalah minuman beras fermentasi Jepang dengan sejarah panjang dalam budaya setempat. Dalam katalog DrinkQ, Sake ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada mixed, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Sake memiliki konteks asal yang berkaitan dengan Japan. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Sake menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Fermentasikan beras, koji, dan air.",
      "Versi konsumsi rumahan biasanya dibeli siap minum."
    ],
    "tasteNotes": [
      "Mixed",
      "Classic"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/sake.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Sake",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Japan",
    "isPublished": true
  },
  {
    "id": "drink-soju",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Soju",
    "slug": "soju",
    "origin": "Korea",
    "originRegion": "Asia",
    "shortDescription": "Soju adalah minuman suling Korea yang menjadi ikon budaya minum modern dan tradisional.",
    "story": "Soju adalah minuman suling Korea yang menjadi ikon budaya minum modern dan tradisional. Dalam katalog DrinkQ, Soju ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, Refreshing, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Soju memiliki konteks asal yang berkaitan dengan Korea. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Soju menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Sajikan dingin langsung.",
      "Untuk versi koktail bisa dicampur soda atau jus."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing",
      "Mixed"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/soju.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Soju",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Korea",
    "isPublished": true
  },
  {
    "id": "drink-makgeolli",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Makgeolli",
    "slug": "makgeolli",
    "origin": "Korea",
    "originRegion": "Asia",
    "shortDescription": "Makgeolli adalah minuman beras fermentasi Korea dengan tekstur keruh.",
    "story": "Makgeolli adalah minuman beras fermentasi Korea dengan tekstur keruh. Dalam katalog DrinkQ, Makgeolli ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada refreshing, dan Classic, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Makgeolli memiliki konteks asal yang berkaitan dengan Korea. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Makgeolli menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Fermentasikan nasi dengan nuruk dan air, lalu saring kasar."
    ],
    "tasteNotes": [
      "Refreshing",
      "Classic"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/makgeolli.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Makgeolli",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Korea",
    "isPublished": true
  },
  {
    "id": "drink-aperol-spritz",
    "type": "drink",
    "category": "cocktail",
    "categoryLabel": "Koktail / alkohol",
    "name": "Aperol Spritz",
    "slug": "aperol-spritz",
    "origin": "Italy",
    "originRegion": "Europe",
    "shortDescription": "Spritz berasal dari tradisi aperitivo Italia dan kini populer global.",
    "story": "Spritz berasal dari tradisi aperitivo Italia dan kini populer global. Dalam katalog DrinkQ, Aperol Spritz ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, Refreshing, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Aperol Spritz memiliki konteks asal yang berkaitan dengan Italy. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Aperol Spritz menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Campur Aperol, prosecco, dan soda dengan es."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing",
      "Mixed"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/aperol-spritz.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Spritz_(cocktail)",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Italy",
    "isPublished": true
  },
  {
    "id": "drink-arnold-palmer",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Arnold Palmer",
    "slug": "arnold-palmer",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Arnold Palmer memadukan teh es dan lemonade, lalu populer luas di Amerika.",
    "story": "Arnold Palmer memadukan teh es dan lemonade, lalu populer luas di Amerika. Dalam katalog DrinkQ, Arnold Palmer ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada tea-based, Aromatic, dan Fruity, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Arnold Palmer memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Arnold Palmer menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur teh hitam dingin dengan lemonade dalam rasio seimbang."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic",
      "Fruity"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/arnold-palmer.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Arnold_Palmer",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-shirley-temple",
    "type": "drink",
    "category": "refreshment",
    "categoryLabel": "Minuman umum",
    "name": "Shirley Temple",
    "slug": "shirley-temple",
    "origin": "US",
    "originRegion": "Americas",
    "shortDescription": "Shirley Temple adalah mocktail klasik yang populer sebagai minuman non-alkohol.",
    "story": "Shirley Temple adalah mocktail klasik yang populer sebagai minuman non-alkohol. Dalam katalog DrinkQ, Shirley Temple ditempatkan sebagai minuman umum yang penyegar harian yang sederhana, praktis, dan banyak ditemui di berbagai tempat. Catatan rasanya cenderung menonjol pada fruity, Fresh, dan Spiced, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Shirley Temple memiliki konteks asal yang berkaitan dengan US. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Shirley Temple menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan utama minuman",
      "Air atau es",
      "Pemanis opsional"
    ],
    "steps": [
      "Campur ginger ale/lemon-lime soda dengan grenadine dan es."
    ],
    "tasteNotes": [
      "Fruity",
      "Fresh",
      "Spiced"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/shirley-temple.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Shirley_Temple",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "US",
    "isPublished": true
  },
  {
    "id": "drink-virgin-mojito",
    "type": "drink",
    "category": "mocktail",
    "categoryLabel": "Mocktail / non-alkohol",
    "name": "Virgin Mojito",
    "slug": "virgin-mojito",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Virgin mojito adalah adaptasi non-alkohol dari mojito klasik.",
    "story": "Virgin mojito adalah adaptasi non-alkohol dari mojito klasik. Dalam katalog DrinkQ, Virgin Mojito ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, Refreshing, dan Mixed, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Virgin Mojito memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Virgin Mojito menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Muddle mint, gula, dan lime.",
      "Tambahkan es dan soda tanpa rum."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing",
      "Mixed"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/virgin-mojito.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Mojito",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-virgin-pina-colada",
    "type": "drink",
    "category": "mocktail",
    "categoryLabel": "Mocktail / non-alkohol",
    "name": "Virgin Piña Colada",
    "slug": "virgin-pina-colada",
    "origin": "Global",
    "originRegion": "Global",
    "shortDescription": "Versi tanpa alkohol ini mengikuti profil tropis piña colada klasik.",
    "story": "Versi tanpa alkohol ini mengikuti profil tropis piña colada klasik. Dalam katalog DrinkQ, Virgin Piña Colada ditempatkan sebagai koktail / alkohol yang racikan bar klasik yang dikenal lewat komposisi, aroma, dan teknik penyajiannya. Catatan rasanya cenderung menonjol pada sparkling, dan Refreshing, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Virgin Piña Colada memiliki konteks asal yang berkaitan dengan Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Virgin Piña Colada menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Bahan dasar minuman sesuai resep klasik",
      "Es batu",
      "Garnish atau buah pelengkap"
    ],
    "steps": [
      "Blender krim kelapa, jus nanas, dan es."
    ],
    "tasteNotes": [
      "Sparkling",
      "Refreshing"
    ],
    "featured": false,
    "imageUrl": "assets/images/drinks/virgin-pina-colada.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Pi%C3%B1a_colada",
    "relatedIngredientIds": [],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Global",
    "isPublished": true
  },
  {
    "id": "drink-iced-matcha",
    "type": "drink",
    "category": "tea",
    "categoryLabel": "Teh / tea",
    "name": "Iced Matcha",
    "slug": "iced-matcha",
    "origin": "Japan/Global",
    "originRegion": "Global",
    "shortDescription": "Iced matcha adalah adaptasi modern dari minuman matcha tradisional.",
    "story": "Iced matcha adalah adaptasi modern dari minuman matcha tradisional. Dalam katalog DrinkQ, Iced Matcha ditempatkan sebagai teh / tea yang berbasis teh dengan aroma herbal atau floral yang kuat dan fleksibel disajikan panas maupun dingin. Catatan rasanya cenderung menonjol pada tea-based, Aromatic, dan Creamy, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Iced Matcha memiliki konteks asal yang berkaitan dengan Japan/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Iced Matcha menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Teh atau matcha",
      "Air panas/dingin",
      "Gula, susu, atau es opsional"
    ],
    "steps": [
      "Kocok matcha dengan air, tambahkan es dan susu/air."
    ],
    "tasteNotes": [
      "Tea-based",
      "Aromatic",
      "Creamy"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/iced-matcha.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Iced_Matcha",
    "relatedIngredientIds": [
      "ingredient-matcha",
      "ingredient-green-tea"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Japan/Global",
    "isPublished": true
  },
  {
    "id": "drink-espresso-tonic",
    "type": "drink",
    "category": "coffee",
    "categoryLabel": "Kopi / coffee",
    "name": "Espresso Tonic",
    "slug": "espresso-tonic",
    "origin": "Nordic/Global",
    "originRegion": "Global",
    "shortDescription": "Espresso tonic populer dari budaya kafe modern dan specialty coffee.",
    "story": "Espresso tonic populer dari budaya kafe modern dan specialty coffee. Dalam katalog DrinkQ, Espresso Tonic ditempatkan sebagai kopi / coffee yang berbasis kopi dengan aroma panggang, body yang terasa, dan karakter yang cocok untuk eksplorasi espresso maupun seduhan dingin. Catatan rasanya cenderung menonjol pada roasted, Aromatic, dan Sparkling, sehingga pembaca bisa memahami alasan minuman ini populer sebelum mencoba resep dasarnya.",
    "history": "Espresso Tonic memiliki konteks asal yang berkaitan dengan Nordic/Global. Perkembangannya dipengaruhi oleh bahan lokal, kebiasaan penyajian, dan perubahan selera masyarakat dari waktu ke waktu. Karena mudah dikenali dan sering muncul dalam budaya kuliner, Espresso Tonic menjadi salah satu contoh penting untuk memahami ragam minuman dunia.",
    "ingredients": [
      "Kopi atau espresso",
      "Air panas/dingin",
      "Susu, gula, atau es sesuai resep"
    ],
    "steps": [
      "Tuang tonic dingin ke gelas berisi es lalu tambah espresso perlahan."
    ],
    "tasteNotes": [
      "Roasted",
      "Aromatic",
      "Sparkling"
    ],
    "featured": true,
    "imageUrl": "assets/images/drinks/espresso-tonic.svg",
    "sourceUrl": "https://en.wikipedia.org/wiki/Espresso_tonic",
    "relatedIngredientIds": [
      "ingredient-arabica",
      "ingredient-robusta"
    ],
    "likesCount": 0,
    "dislikesCount": 0,
    "discoveredAt": "Nordic/Global",
    "isPublished": true
  }
];
