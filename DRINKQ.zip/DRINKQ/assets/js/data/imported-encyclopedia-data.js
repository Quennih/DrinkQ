// DrinkQ static encyclopedia database index.
import { importedDrinks } from './drinks.js';
import { importedIngredients } from './ingredients.js';

export { importedDrinks, importedIngredients };
