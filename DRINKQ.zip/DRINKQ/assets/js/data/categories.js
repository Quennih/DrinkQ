// DrinkQ static categories database.
export const drinkCategories = [
  { id: 'coffee', label: 'Kopi / coffee' },
  { id: 'tea', label: 'Teh / tea' },
  { id: 'juice', label: 'Buah / dairy / dessert' },
  { id: 'refreshment', label: 'Minuman umum' }
];

export const ingredientCategories = [
  { id: 'coffee-bean', label: 'Biji kopi' },
  { id: 'tea-leaf', label: 'Daun teh' },
  { id: 'general', label: 'Bahan umum' }
];
